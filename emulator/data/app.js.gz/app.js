(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))i(a);new MutationObserver(a=>{for(const n of a)if(n.type==="childList")for(const c of n.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&i(c)}).observe(document,{childList:!0,subtree:!0});function t(a){const n={};return a.integrity&&(n.integrity=a.integrity),a.referrerPolicy&&(n.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?n.credentials="include":a.crossOrigin==="anonymous"?n.credentials="omit":n.credentials="same-origin",n}function i(a){if(a.ep)return;a.ep=!0;const n=t(a);fetch(a.href,n)}})();let G=!1;const D=globalThis.console,J={log:D.log.bind(D),info:D.info.bind(D),debug:D.debug?D.debug.bind(D):D.log.bind(D),warn:D.warn.bind(D),error:D.error.bind(D)},ae=()=>{};function Se(){D.log=ae,D.info=ae,D.debug=ae,D.warn=(...s)=>{G&&J.warn(...s)},D.error=(...s)=>{G&&J.error(...s)}}function De(){return new Date().toLocaleTimeString("it-IT",{hour:"2-digit",minute:"2-digit",second:"2-digit",fractionalSecondDigits:3})}function ye(s,e){const t=De(),i=`[${s.toUpperCase()}]`;return`${t} ${i} ${e}`}function Oe(s,...e){}function Re(s,...e){}function we(s,...e){G&&J.warn(ye("warn",s),...e)}function Ne(s,...e){G&&J.error(ye("error",s),...e)}function Te(s){G=!!s,Se()}function Pe(s){Te(s)}function Be(){return G}Se();const o={debug:Oe,info:Re,warn:we,error:Ne,setDebugMode:Te,setLogEnabled:Pe,isDebugEnabled:Be},$e={FORCED_DISCONNECT:"FORCE_DISCONNECT"},L={CONNECTING:"connecting",CONNECTED:"connected",DISCONNECTED:"disconnected",RECONNECTING:"reconnecting"},y=(()=>{let s={telemetry:{rpm:1200,tps:0,egt:20,ecu_advance:15,spark_detected:!0},overrides:{tps:{active:!1,value:0},egt:{active:!1,value:20},rpm:{active:!1,value:1200},egt_fault:{active:!1}},socket:{state:L.DISCONNECTED}};const e={},t={};function i(f){return f.length===1?Array.isArray(f[0])?f[0].join("."):f[0]:Array.from(f).join(".")}function a(f){if(!f||typeof f!="string")return{valid:!1,error:"Path vuoto o non valido"};const l=f.split(".");let r=s,u=[];for(let v=0;v<l.length;v++){const A=l[v];if(u.push(A),r==null)return{valid:!1,error:`Path non valido: ${u.join(".")} → valore undefined/null`};if(!(A in r))return{valid:!1,error:`Path non valido: proprietà "${A}" non esiste in ${u.slice(0,-1).join(".")}`};r=r[A]}return typeof r=="object"&&r!==null&&!Array.isArray(r)&&Object.keys(r).length>0?{valid:!1,error:`Path incompleto: ${f} punta a un oggetto con proprietà [${Object.keys(r).join(", ")}]`}:{valid:!0,finalValue:r}}function n(...f){const l=i(f),r=a(l);if(!r.valid)throw console.error(`[Store.get] ${r.error}`),new Error(`[Store.get] ${r.error}`);return r.finalValue}function c(...f){const l=f.pop(),r=i(f);if(!r)throw console.error("[Store.set] Path vuoto",f),new Error("[Store.set] Path vuoto");const u=r.split(".");let v=s;for(let $=0;$<u.length-1;$++){const x=u[$];if(!(x in v))throw console.error(`[Store.set] Path non valido: ${r} (errore a "${x}")`),new Error(`[Store.set] Path non valido: ${r}`);v=v[x]}const A=u[u.length-1];if(!(A in v))throw console.error(`[Store.set] Path non valido: ${r} (proprietà "${A}" non esiste)`),new Error(`[Store.set] Path non valido: ${r}`);const w=v[A],R=!t[r];r!=="config.menu"&&!R&&w===l||(v[A]=l,R&&(t[r]=!0),e[r]&&e[r].forEach(($,x)=>{try{$(l,w)}catch(H){console.error(`[Store] Errore nel callback per path "${r}":`,H)}}))}function g(f,l,r=!0){if(typeof f!="string")throw console.error("[Store.subscribe] Path deve essere una stringa",f),new Error("[Store.subscribe] Path deve essere una stringa");if(typeof l!="function")throw console.error("[Store.subscribe] Callback deve essere una funzione",l),new Error("[Store.subscribe] Callback deve essere una funzione");const u=a(f);if(!u.valid)throw console.error(`[Store.subscribe] ${u.error}`),new Error(`[Store.subscribe] ${u.error}`);if(e[f]||(e[f]=[]),e[f].push(l),r&&u.valid){const v=u.finalValue;setTimeout(()=>{try{l(v,void 0)}catch(A){console.error(`[Store.subscribe] Errore in callback immediato per path "${f}":`,A)}},0)}return()=>{const v=e[f].indexOf(l);v>=0&&e[f].splice(v,1),e[f].length===0&&delete e[f]}}function b(){return JSON.parse(JSON.stringify(s))}function m(){s.telemetry={rpm:1200,tps:0,egt:20,ecu_advance:15,spark_detected:!0},s.overrides={tps:{active:!1,value:0},egt:{active:!1,value:20},rpm:{active:!1,value:1200},egt_fault:{active:!1}},s.socket.state=L.DISCONNECTED,Object.keys(t).forEach(f=>delete t[f])}function E(){return Object.keys(e).map(f=>({path:f,count:e[f].length}))}function S(){const l=Object.keys(e).filter(r=>Array.isArray(e[r])&&e[r].length>0).map(r=>({path:r,callbacks:e[r].slice()}));for(const{path:r,callbacks:u}of l){let v;try{v=n(r)}catch(A){console.error(`[STORE] updateAllListeners() skip path "${r}" (get error):`,A);continue}u.forEach((A,w)=>{try{A(v,void 0)}catch(R){console.error(`[STORE] updateAllListeners() callback error path="${r}" #${w+1}/${u.length}:`,R)}})}}return{get:n,set:c,subscribe:g,getState:b,reset:m,_debugListeners:E,updateAllListeners:S}})(),xe=Object.freeze(Object.defineProperty({__proto__:null,Store:y},Symbol.toStringTag,{value:"Module"})),I={TELEMETRY:{RPM:"telemetry.rpm",TPS:"telemetry.tps",EGT:"telemetry.egt",ECU_ADVANCE:"telemetry.ecu_advance",SPARK_DETECTED:"telemetry.spark_detected"},OVERRIDES:{TPS:{ACTIVE:"overrides.tps.active",VALUE:"overrides.tps.value"},EGT:{ACTIVE:"overrides.egt.active",VALUE:"overrides.egt.value"},RPM:{ACTIVE:"overrides.rpm.active",VALUE:"overrides.rpm.value"},EGT_FAULT:{ACTIVE:"overrides.egt_fault.active"}},SOCKET:{STATE:"socket.state"}},qe=Object.freeze(Object.defineProperty({__proto__:null,Paths:I},Symbol.toStringTag,{value:"Module"})),Ce={ENGLISH:0},Ue={[Ce.ENGLISH]:{ui:{loading:"Loading...",error:"Error",save:"Save",cancel:"Cancel",confirm:"Confirm",close:"Close",ok:"OK",back:"Back",connected:"CONNECTED",connecting:"CONNECTING",disconnected:"DISCONNECTED",reconnecting:"RECONNECTING",dashboardTitle:"ECU TEST SYSTEM",rpm:"Engine Speed (RPM)",tps:"Throttle Position (TPS)",egt:"Exhaust Gas Temp (EGT)",ignitionAdvance:"Ignition Timing Advance",sparkDetected:"Spark Detected",sparkActive:"Spark Active",sparkInactive:"No Spark",qsTrigger:"QUICK SHIFT",manualOverride:"Manual Override",physicalInput:"Physical Input",egtFault:"EGT Overheat Fault",configure:"Configure",rpmOverrideTitle:"RPM Override Configuration",rpmOverrideDesc:"Manually override the engine speed. Bypasses physical TPS kinematics.",tpsOverrideTitle:"TPS Override Configuration",tpsOverrideDesc:"Manually override Throttle Position Sensor. Virtual input takes precedence.",egtOverrideTitle:"EGT Override Configuration",egtOverrideDesc:"Manually override Exhaust Gas Temp. Bypasses superloop simulation.",targetRpm:"Target RPM",targetTps:"Target Throttle (%)",targetEgt:"Target Temperature (°C)",overrideToggle:"Enable Virtual Override",injectFaultToggle:"Inject EGT Overheat Fault (>800°C)",adcValue:"Physical Input Value",presets:"Quick Presets",active:"Active",inactive:"Inactive"}}};class Ve{getCurrentLangIndex(){return Ce.ENGLISH}t(e,t={}){const i=this.getCurrentLangIndex(),a=Ue[i];if(!a)return e;const n=this._getNestedValue(a,e);return n?this._interpolate(n,t):(o.warn(`Missing translation for key: ${e}`),e)}tMenu(e){return{0:"Dashboard",1:"RPM Settings",2:"TPS Settings",3:"EGT Settings"}[e]||`Menu ${e}`}tParam(e){return{name:`Param ${e}`,ds:""}}tDay(e){return["M","T","W","T","F","S","S"][e]||""}tEnum(e,t){return String(t)}_getNestedValue(e,t){return t.split(".").reduce((i,a)=>i==null?void 0:i[a],e)}_interpolate(e,t){return e.replace(/\{(\w+)\}/g,(i,a)=>t.hasOwnProperty(a)?t[a]:i)}}const _=new Ve;function He(s,e){const t={cmd:"toggle_override",param:s,active:!!e};o.info(`[Command] Toggle override: param=${s}, active=${e}`),B.send(JSON.stringify(t))}function Fe(s,e){const t={cmd:"set_value",param:s,value:Number(e)};o.info(`[Command] Set value: param=${s}, value=${e}`),B.send(JSON.stringify(t))}function Ge(s,e){const t={cmd:"inject_fault",fault:s,active:!!e};o.info(`[Command] Inject fault: fault=${s}, active=${e}`),B.send(JSON.stringify(t))}function ze(){const s={cmd:"qs_trigger"};o.info("[Command] Trigger Quick Shifter"),B.send(JSON.stringify(s))}function je(){o.info("[CommandManager] Initialized")}const M={init:je,toggleOverride:He,setValue:Fe,injectFault:Ge,triggerQs:ze},B=(()=>{const s={disconnectTimeout:2e3,backoffBase:2e3,backoffFactor:2,backoffMax:3e4,initialBackoff:3e3,maxReconnectAttempts:3,pingIntervalMs:2e3,maxSilenceMs:6e4};let e=L.DISCONNECTED,t=null,i=null,a=s.backoffBase,n=null,c=null,g=0,b=0,m=!1,E=0,S=!0;const f=[],l=[],r=[];function u(h){if(m&&h!==L.CONNECTED&&h!==L.DISCONNECTED){e=h;return}e!==h&&(e=h,v(h),f.forEach(k=>k(e)))}function v(h){h===L.DISCONNECTED?(document.body.style.opacity="0.4",document.body.style.transition="opacity 0.3s ease"):(document.body.style.opacity="1",document.body.style.transition="opacity 0.3s ease")}function A(){clearTimeout(n);const h=Date.now();let k=s.disconnectTimeout;E>h&&(k=E-h+s.disconnectTimeout),n=setTimeout(()=>{console.warn("⚠️ ESP non risponde da troppo tempo, considerato offline"),console.warn("⏱️ Nessun messaggio ricevuto per",k,"ms"),u("disconnected"),R(),S&&w()},k)}function w(){if(!S)return;clearTimeout(c),b++;let h;if(g>0?(h=g,g=0):h=a===s.backoffBase?s.initialBackoff:a,b>=s.maxReconnectAttempts){console.warn(`⚠️ Raggiunto limite di ${s.maxReconnectAttempts} tentativi - stato: DISCONNECTED`),m=!0,u(L.DISCONNECTED);return}u(L.RECONNECTING),c=setTimeout(()=>{a=Math.min(a*s.backoffFactor,s.backoffMax),U()},h)}function R(){if(t){try{t.close(1e3,"Client closed")}catch(h){}t=null}}function $(){}function x(){}function H(h){i=h.url||h.asyncUrl||null}function U(){if(!i)throw new Error("Socket config non inizializzata! Usa setConfig(url) prima di connect().");R(),u(L.CONNECTING);try{t=new WebSocket(`ws://${i}`),t.onopen=()=>{clearTimeout(c),a=s.backoffBase,b=0,m=!1,S=!0,ie(),u(L.CONNECTED);const h=r.slice();h.forEach((k,N)=>{try{k()}catch(P){console.error(`⚠️ [Socket.onOpen] subscriber error #${N+1}/${h.length}:`,P)}})},t.onmessage=h=>{const k=String(h.data).trim();if(A(),k.startsWith($e.FORCED_DISCONNECT)){const N=k.split("|"),P=N[1]||"Unknown reason";let j=0;for(let Z=2;Z<N.length;Z++)N[Z].startsWith("retryAfterMs=")&&(j=parseInt(N[Z].split("=")[1])||0);if(P==="REPLACED"){console.warn("🚫 ══════════════════════════════════════════════════════════"),console.warn("🚫 SESSION REPLACED BY ANOTHER PAGE"),console.warn("🚫 Auto-reconnect PERMANENTLY disabled"),console.warn("🚫 Refresh (F5) to regain control"),console.warn("🚫 ══════════════════════════════════════════════════════════"),S=!1,m=!0,clearTimeout(c),clearTimeout(n),R(),u(L.DISCONNECTED),ve();return}(P==="SERVER_FULL"||P==="IDLE_TIMEOUT")&&j>0?(console.warn("⏳ FORCED_DISCONNECT temporaneo:",P,"— retry tra",j,"ms"),clearTimeout(c),clearTimeout(n),R(),u(L.DISCONNECTED),g=j,b=0,m=!1,c=setTimeout(()=>{a=s.backoffBase,U()},j)):(console.warn("🚨 ════════════════════════════════════════════════════════"),console.warn("🚨 ESP HA FORZATO LA DISCONNESSIONE"),console.warn("🚨 Motivo:",P),console.warn("🚨 Reconnect automatico DISABILITATO"),console.warn("🚨 ════════════════════════════════════════════════════════"),m=!0,clearTimeout(c),clearTimeout(n),u(L.DISCONNECTED),R());return}l.forEach(N=>N(k))},t.onclose=h=>{clearTimeout(n),u(L.DISCONNECTED),S&&w()},t.onerror=h=>{console.error("⚠️ WS errore:",h),u(L.DISCONNECTED),R(),S&&w()}}catch(h){console.error("⚠️ WS eccezione:",h),u(L.DISCONNECTED),S&&w()}}function Y(h){if(!S){console.warn("🚫 Send blocked: session replaced. Refresh to reconnect.");return}t&&t.readyState===WebSocket.OPEN?t.send(h):console.warn("⚠️ Tentativo di invio senza connessione:",h)}function z(){clearTimeout(c),clearTimeout(n),R(),u(L.DISCONNECTED)}function Q(h){return typeof h!="function"?()=>{}:(f.includes(h)||f.push(h),()=>{const k=f.indexOf(h);k>=0&&f.splice(k,1)})}function se(h){return typeof h!="function"?()=>{}:(l.includes(h)||l.push(h),()=>{const k=l.indexOf(h);k>=0&&l.splice(k,1)})}function F(h){return typeof h!="function"?()=>{}:(r.includes(h)||r.push(h),()=>{const k=r.indexOf(h);k>=0&&r.splice(k,1)})}window.addEventListener("beforeunload",()=>{z()}),document.addEventListener("visibilitychange",()=>{document.visibilityState==="hidden"?c=setTimeout(()=>{document.visibilityState==="hidden"&&t&&(R(),u(L.DISCONNECTED))},5e3):document.visibilityState==="visible"&&(clearTimeout(c),e!==L.CONNECTED&&S&&(a=s.backoffBase,b=0,m=!1,U()))}),window.addEventListener("wifi-silence",h=>{var P;const k=((P=h.detail)==null?void 0:P.silenceMs)||0;if(k<=0)return;const N=Math.min(k,s.maxSilenceMs);E=Date.now()+N,A()});function ve(){if(document.getElementById("ws-replaced-overlay"))return;const h=document.createElement("div");h.id="ws-replaced-overlay",h.style.cssText=`
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0,0,0,0.65); z-index: 99999;
      display: flex; align-items: center; justify-content: center;
      pointer-events: auto;
    `,h.innerHTML=`
      <div style="
        background: #1a1a2e; color: #e0e0e0; border-radius: 16px;
        padding: 32px 28px; max-width: 380px; text-align: center;
        box-shadow: 0 8px 32px rgba(0,0,0,0.4); font-family: system-ui, sans-serif;
      ">
        <div style="font-size: 48px; margin-bottom: 12px;">🚫</div>
        <h2 style="margin: 0 0 8px; font-size: 18px; color: #ff6b6b;">Sessione Sostituita</h2>
        <p style="margin: 0 0 20px; font-size: 14px; line-height: 1.5; color: #aaa;">
          Un'altra pagina ha preso il controllo.<br>
          Ricarica per riprendere la connessione.
        </p>
        <button onclick="location.reload()" style="
          background: #4a90d9; color: white; border: none; border-radius: 8px;
          padding: 12px 32px; font-size: 15px; cursor: pointer;
          font-weight: 600; transition: background 0.2s;
        " onmouseover="this.style.background='#5aa0e9'"
           onmouseout="this.style.background='#4a90d9'">Ricarica Pagina</button>
      </div>
    `,document.body.appendChild(h)}function ie(){const h=document.getElementById("ws-replaced-overlay");h&&h.remove()}return{setConfig:H,connect:U,send:Y,close:z,onStatus:Q,onMessage:se,onOpen:F,CONFIG:s}})(),We=Object.freeze(Object.defineProperty({__proto__:null,Socket:B},Symbol.toStringTag,{value:"Module"}));function Ke(s){var e,t,i,a,n,c,g;if(typeof s=="string")try{const b=JSON.parse(s);if(b.type==="sim_telemetry"&&b.data){const m=b.data;if(y.set(I.TELEMETRY.RPM,(e=m.rpm)!=null?e:0),y.set(I.TELEMETRY.TPS,(t=m.tps)!=null?t:0),y.set(I.TELEMETRY.EGT,(i=m.egt)!=null?i:0),y.set(I.TELEMETRY.ECU_ADVANCE,(a=m.ecu_advance)!=null?a:0),y.set(I.TELEMETRY.SPARK_DETECTED,!!m.spark_detected),m.overrides){const E=!!m.overrides.tps,S=!!m.overrides.egt,f=!!m.overrides.rpm;y.set(I.OVERRIDES.TPS.ACTIVE,E),y.set(I.OVERRIDES.EGT.ACTIVE,S),y.set(I.OVERRIDES.RPM.ACTIVE,f),y.set(I.OVERRIDES.EGT_FAULT.ACTIVE,!!m.overrides.egt_fault),E&&y.set(I.OVERRIDES.TPS.VALUE,(n=m.tps)!=null?n:0),S&&y.set(I.OVERRIDES.EGT.VALUE,(c=m.egt)!=null?c:20),f&&y.set(I.OVERRIDES.RPM.VALUE,(g=m.rpm)!=null?g:1200)}}}catch(b){console.error("[Adapter] Failed to parse WebSocket message:",b,s)}}const p={pages:new Map,navigationStack:[],currentPageId:null,maxStackDepth:3,isNavigating:!1,initialized:!1,popstateHandler:null};function X(s){return document.getElementById(s)}function ue(s,e,t="forward"){const i=s?X(s):null,a=X(e);if(!a){console.error(`❌ Pagina "${e}" non trovata nel DOM`);return}i&&(i.classList.remove("active","right"),i.classList.add("left")),a.classList.remove("left","right"),a.classList.add("active")}function pe(s,e={}){const t=p.pages.get(s);if(t&&typeof t.activate=="function")try{t.activate(e)}catch(i){console.error(`❌ Errore in ${s}.activate():`,i)}}function ge(s){const e=p.pages.get(s);if(e&&typeof e.deactivate=="function")try{e.deactivate()}catch(t){console.error(`❌ Errore in ${s}.deactivate():`,t)}}function Ye(){p.navigationStack.length>p.maxStackDepth&&p.navigationStack.splice(1,1)}function ke(s,e=null){if(!s){console.error("❌ NavigatorManager.registerPage: pageId è obbligatorio");return}const t=X(s);t||console.warn(`⚠️ Pagina "${s}" non trovata nel DOM, registrata comunque`),p.pages.set(s,e),!p.currentPageId&&t&&t.classList.contains("active")&&!p.navigationStack.includes(s)&&(p.currentPageId=s,p.navigationStack.push(s))}function Ie(s,e={},t=!1){if(s!=="pinPage")try{if(y.get(I.APP.AUTH.LOCKED)){console.warn(`🔒 [NavigatorManager] Navigation to "${s}" blocked — PIN required`),p.currentPageId!=="pinPage"&&Ie("pinPage",{},!0);return}}catch(n){}if(p.isNavigating){console.warn("⚠️ Navigazione già in corso, richiesta ignorata");return}if(!s){console.error("❌ NavigatorManager.navigateTo: pageId è obbligatorio");return}if(!X(s)){console.error(`❌ Pagina "${s}" non trovata nel DOM`);return}if(p.currentPageId===s)return;p.isNavigating=!0;const a=p.currentPageId;a&&ge(a),ue(a,s,"forward"),t&&p.navigationStack.length>0?p.navigationStack[p.navigationStack.length-1]=s:(p.navigationStack.push(s),Ye()),p.currentPageId=s,pe(s,e),window.history&&window.history.pushState({pageId:s},"",`#${s}`),setTimeout(()=>{p.isNavigating=!1},300)}function _e(){try{if(y.get(I.APP.AUTH.LOCKED)){console.warn("🔒 [NavigatorManager] goBack() blocked — PIN required");return}}catch(t){}if(p.isNavigating){console.warn("⚠️ Navigazione già in corso, richiesta ignorata");return}if(p.navigationStack.length<=1)return;p.isNavigating=!0;const s=p.navigationStack.pop(),e=p.navigationStack[p.navigationStack.length-1];ge(s),ue(s,e,"backward"),p.currentPageId=e,pe(e,{}),window.history&&window.history.back(),setTimeout(()=>{p.isNavigating=!1},300)}function Qe(){try{if(y.get(I.APP.AUTH.LOCKED)){console.warn("🔒 [NavigatorManager] goHome() blocked — PIN required");return}}catch(t){}if(p.navigationStack.length===0){console.warn("⚠️ Nessuna pagina home definita");return}if(p.isNavigating){console.warn("⚠️ Navigazione già in corso, richiesta ignorata");return}const s=p.navigationStack[0];if(!s){console.error("❌ Home page non trovata nello stack");return}if(p.currentPageId===s){p.navigationStack.length>1&&(p.navigationStack=[s]);return}p.isNavigating=!0;const e=p.currentPageId;e&&ge(e),ue(e,s,"backward"),p.navigationStack=[s],p.currentPageId=s,pe(s,{}),setTimeout(()=>{p.isNavigating=!1},300)}function Ze(){return p.currentPageId}function Je(){return[...p.navigationStack]}function Xe(s){if(typeof s!="number"||s<1){console.warn("⚠️ setMaxStackDepth: depth deve essere un numero >= 1");return}p.maxStackDepth=s}function et(){if(p.initialized)return;p.popstateHandler=e=>{try{if(y.get(I.APP.AUTH.LOCKED)){window.history.pushState({pageId:"pinPage"},"","#pinPage");return}}catch(t){}e.state&&e.state.pageId},window.addEventListener("popstate",p.popstateHandler),document.querySelectorAll(".page").forEach(e=>{const t=e.id;t&&!p.pages.has(t)&&ke(t),e.classList.contains("active")||(e.classList.remove("right"),e.classList.add("left"))}),p.initialized=!0}function tt(){return{pages:Array.from(p.pages.keys()),stack:p.navigationStack,current:p.currentPageId,maxDepth:p.maxStackDepth,isNavigating:p.isNavigating}}function st(){p.popstateHandler&&(window.removeEventListener("popstate",p.popstateHandler),p.popstateHandler=null),p.pages.clear(),p.navigationStack=[],p.currentPageId=null,p.maxStackDepth=3,p.isNavigating=!1,p.initialized=!1}const V={init:et,registerPage:ke,navigateTo:Ie,goBack:_e,goHome:Qe,getCurrentPage:Ze,getNavigationStack:Je,setMaxStackDepth:Xe,_debug:tt,_reset:st},T={HIGH:10,NORMAL:5,LOW:1},ce="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxIiBoZWlnaHQ9IjEiPjxyZWN0IHdpZHRoPSIxIiBoZWlnaHQ9IjEiIGZpbGw9IiNlMGUwZTAiLz48L3N2Zz4=",it={"logo-idrobase":{url:"./assets/img/logo-idrobase.png",priority:T.NORMAL,alt:"Idrobase"},"logo-product":{url:"./assets/img/logo-product.png",priority:T.HIGH,alt:"Nebulizzatore"},"icon-hamburger-menu":{url:"./assets/icons/icon-hamburger-menu.png",priority:T.HIGH,alt:"Menu"},"icon-wifi-free":{url:"./assets/icons/icon-wifi-free.png",priority:T.LOW,alt:"WiFi Free"},"icon-wifi":{url:"./assets/icons/icon-wifi.png",priority:T.LOW,alt:"WiFi Status"},"icon-wifi-lock":{url:"./assets/icons/icon-wifi-lock.png",priority:T.LOW,alt:"WiFi Locked"},"icon-timer":{url:"./assets/icons/icon-timer.png",priority:T.NORMAL,alt:"Timer"},"icon-calendar":{url:"./assets/icons/icon-calendar.png",priority:T.NORMAL,alt:"Calendar"},"icon-thermo":{url:"./assets/icons/icon-thermo.png",priority:T.NORMAL,alt:"Temperature"},"icon-humidity":{url:"./assets/icons/icon-humidity.png",priority:T.NORMAL,alt:"Humidity"},"icon-setting":{url:"./assets/icons/icon-setting.png",priority:T.LOW,alt:"Settings"},"icon-antibacterial":{url:"./assets/icons/icon-antibacterial.png",priority:T.LOW,alt:"Antibacterial"},"icon-modbus":{url:"./assets/icons/icon-modbus.png",priority:T.LOW,alt:"Modbus"},"icon-sun":{url:"./assets/icons/icon-sun.png",priority:T.HIGH,alt:"Day Mode"},"icon-moon":{url:"./assets/icons/icon-moon.png",priority:T.HIGH,alt:"Night Mode"},"icon-dispenser":{url:"./assets/icons/icon-dispenser.png",priority:T.LOW,alt:"Dispenser"},"icon-fan":{url:"./assets/icons/icon-fan.png",priority:T.LOW,alt:"Fan"},"icon-pump":{url:"./assets/icons/icon-pump.png",priority:T.HIGH,alt:"Pump"},"icon-send":{url:"./assets/icons/icon-send.png",priority:T.LOW,alt:"Send"},"icon-lang-en":{url:"./assets/img/flags/icon-lang-en.png",priority:T.NORMAL,alt:"English"},"icon-lang-it":{url:"./assets/img/flags/icon-lang-it.png",priority:T.NORMAL,alt:"Italiano"},"icon-lang-de":{url:"./assets/img/flags/icon-lang-de.png",priority:T.LOW,alt:"Deutsch"},"icon-lang-es":{url:"./assets/img/flags/icon-lang-es.png",priority:T.LOW,alt:"Español"},"icon-lang-fr":{url:"./assets/img/flags/icon-lang-fr.png",priority:T.NORMAL,alt:"Français"}};function at(s){const e=it[s];if(!e)return null;let t=e.url;try{t=new URL(e.url,window.location.origin).href}catch(i){console.warn(`[AssetCatalog] Impossibile normalizzare URL per la chiave '${s}'`,i)}return{key:s,urlOriginal:e.url,urlCanonico:t,priority:e.priority!==void 0?e.priority:T.NORMAL,fallback:e.fallback||ce,alt:e.alt||""}}const ne={MAX_CONCURRENT:1,MAX_RETRIES:2,RETRY_DELAY_MS:800},O={IDLE:"idle",QUEUED:"queued",LOADING:"loading",LOADED:"loaded",FAILED:"failed"},W=(()=>{const s=new Map,e=new Map;let t=0,i=0;function a(l){return{key:l.key,urlCanonico:l.urlCanonico,status:O.IDLE,priority:l.priority,sequenceNumber:0,attempts:0,resource:null,fallback:l.fallback,subscribers:new Map,error:null,lastUsedAt:Date.now()}}function n(){const l=Array.from(s.values()).filter(r=>r.status===O.QUEUED);if(l.length!==0)for(l.sort((r,u)=>u.priority!==r.priority?u.priority-r.priority:r.sequenceNumber-u.sequenceNumber);t<ne.MAX_CONCURRENT&&l.length>0;){const r=l.shift();c(r)}}async function c(l){l.status=O.LOADING,l.attempts++,t++;try{const r=await fetch(l.urlCanonico);if(!r.ok)throw new Error(`HTTP Fetch Failed: ${r.status}`);const u=await r.blob();l.resource=URL.createObjectURL(u),l.status=O.LOADED,l.error=null,g(l)}catch(r){console.warn(`[ImageManager] Fallimento fetching per asset '${l.key}' (Tentativo ${l.attempts}):`,r),l.attempts<ne.MAX_RETRIES?(l.status=O.IDLE,setTimeout(()=>{l.status===O.IDLE&&(l.status=O.QUEUED,l.sequenceNumber=i++,n())},ne.RETRY_DELAY_MS)):(l.status=O.FAILED,l.error=r.message||"Retry Exhausted")}finally{t--,n()}}function g(l){if(l.status===O.LOADED)for(const[r,u]of l.subscribers.entries()){if(typeof u.isValid=="function"&&!u.isValid()){E(l.key,r);continue}try{u.onAssetReady(l.resource)}catch(v){console.error(`[ImageManager] Errore nell'handler onAssetReady del subscriber '${r}':`,v)}}}function b(l,r){if(!l||!r||!r.id||typeof r.onAssetReady!="function")return console.error("[ImageManager] requestAsset invocato con parametri non validi",{key:l,subscriberId:r==null?void 0:r.id}),{status:O.FAILED,resource:null,fallback:ce,subscribed:!1};const u=at(l);if(!u)return console.warn(`[ImageManager] Asset non mappato nel catalogo: '${l}'`),{status:O.FAILED,resource:null,fallback:ce,subscribed:!1};s.has(l)||s.set(l,a(u));const v=s.get(l);return v.lastUsedAt=Date.now(),v.status===O.LOADED&&v.resource?{status:v.status,resource:v.resource,fallback:v.fallback,subscribed:!1}:v.status===O.FAILED?{status:v.status,resource:null,fallback:v.fallback,subscribed:!1}:(e.has(r.id)||e.set(r.id,new Set),e.get(r.id).add(l),v.subscribers.set(r.id,r),v.status===O.IDLE&&(v.status=O.QUEUED,v.sequenceNumber=i++,setTimeout(n,0)),{status:v.status,resource:null,fallback:v.fallback,subscribed:!0})}function m(l){const r=s.get(l);return r&&r.status===O.LOADED?r.resource:null}function E(l,r){const u=s.get(l);u&&u.subscribers.delete(r);const v=e.get(r);v&&(v.delete(l),v.size===0&&e.delete(r))}function S(l){const r=e.get(l);r&&Array.from(r).forEach(u=>{E(u,l)})}function f(){return{totalEntries:s.size,activeRequests:t,activeSubscribers:e.size,loadedStatusCount:Array.from(s.values()).filter(l=>l.status===O.LOADED).length}}return{requestAsset:b,getLoadedAsset:m,unsubscribe:E,unsubscribeAll:S,getStats:f}})();class q{constructor(e={}){this._options=e,this.id=e.id||`component-${Date.now()}-${Math.random().toString(36).substr(2,9)}`,this.type=this.constructor.name,this.el=typeof e.el=="string"?document.querySelector(e.el):e.el||null,this.state={mounted:!1,active:!1,destroyed:!1},this.phase="created",this.parent=e.parent||null,this.children=[],this.props=e.props||{},this.data={},this.bindings=e.bindings||{},this._storeUnsubscribers=[],this._manualStoreSubscriptions=[],this._listeners=[],this._childComponents=new Map,this._i18nUnsubscribe=null,this._i18nEnabled=!1,this._i18nUpdateCallback=null,this._assetNodesMap=new Map,this._assetSubscriptions=new Map,this.onCreate()}onCreate(){}onMount(){}onActivate(){}onDeactivate(){}onDestroy(){}get element(){return this.el}mount(e){if(this.state.mounted)return console.warn(`[Component] ${this.id} is already mounted`),this;if(this.state.destroyed)return console.error(`[Component] Cannot mount destroyed component ${this.id}`),this;if(!this.el){const t=this.render();if(t){if(typeof t=="string"){const i=document.createElement("div");i.innerHTML=t.trim(),this.el=i.firstElementChild}else t instanceof HTMLElement&&(this.el=t);this.phase="rendered"}}return e&&this.el&&e.appendChild(this.el),this.state.mounted=!0,this.onMount(),this._setupI18nBinding(),this.children.forEach(t=>{t.state.mounted||t.mount(this.el)}),this}bindEvents(){return this.phase==="bound"||this.phase==="active"?(console.warn(`[Component] ${this.id} events already bound (phase: ${this.phase})`),this):this.phase!=="rendered"?(console.warn(`[Component] ${this.id} must be rendered before binding events (current phase: ${this.phase})`),this):(this.phase="bound",this.onBindEvents(),this.children.forEach(e=>{e.phase==="rendered"&&e.bindEvents()}),this)}onBindEvents(){}activate(...e){return this.state.mounted?this.state.active?this:(this._setupBindings(),this.update(),this.state.active=!0,this.phase="active",this.el&&(this.el.classList.add("active"),this.el.classList.remove("inactive")),this.onActivate(...e),this.bindDeferredImages(this.el),this.children.forEach(t=>{t.state.mounted&&!t.state.active&&t.activate()}),this):(console.warn(`[Component] Cannot activate unmounted component ${this.id}`),this)}deactivate(){return this.state.active?(this._teardownBindings(),this.unbindDeferredImages(),this.state.active=!1,this.phase="bound",this.el&&(this.el.classList.remove("active"),this.el.classList.add("inactive")),this.onDeactivate(),this.children.forEach(e=>{e.state.active&&e.deactivate()}),this):this}destroy(){if(this.state.destroyed){console.warn(`[Component] ${this.id} is already destroyed`);return}this.onDestroy(),this.unbindDeferredImages(),this._assetNodesMap&&this._assetNodesMap.clear(),this.children.forEach(e=>e.destroy()),this.children=[],this._childComponents.clear(),this._teardownBindings(),this._teardownManualStoreSubscriptions(),this._teardownI18nBinding(),this._listeners.forEach(({element:e,event:t,handler:i})=>{e.removeEventListener(t,i)}),this._listeners=[],this.el&&this.el.parentNode&&this.el.parentNode.removeChild(this.el),this.state.destroyed=!0,this.state.mounted=!1,this.state.active=!1,this.phase="destroyed",this.el=null}render(){return null}update(){}_setupBindings(){!this.bindings||Object.keys(this.bindings).length===0||Object.entries(this.bindings).forEach(([e,t])=>{this.data[e]=y.get(t);const i=y.subscribe(t,a=>{const n=this.data[e];this.data[e]=a,typeof this.onDataChange=="function"&&this.onDataChange(e,a,n),this.state.mounted&&this.update()});this._storeUnsubscribers.push(i)})}_teardownBindings(){this._storeUnsubscribers.forEach(e=>{typeof e=="function"&&e()}),this._storeUnsubscribers=[]}getData(e){return this.data[e]}setData(e,t){const i=this.data[e];this.data[e]=t,typeof this.onDataChange=="function"&&this.onDataChange(e,t,i),this.state.mounted&&this.update()}enableI18n(e){if(typeof e!="function"){console.warn("[Component] enableI18n: updateCallback must be a function");return}this._i18nEnabled=!0,this._i18nUpdateCallback=e,this.state.mounted&&!this._i18nUnsubscribe&&this._setupI18nBinding()}_setupI18nBinding(){!this._i18nEnabled||this._i18nUnsubscribe||(this._i18nUnsubscribe=_.onLanguageChange(e=>{if(typeof this._i18nUpdateCallback=="function")try{this._i18nUpdateCallback(e)}catch(t){console.error(`[Component] Error in i18n update callback for ${this.type}:`,t)}}))}_teardownI18nBinding(){this._i18nUnsubscribe&&(this._i18nUnsubscribe(),this._i18nUnsubscribe=null)}subscribeToStore(e,t){if(!e||typeof t!="function")return console.warn("[Component] subscribeToStore: Invalid arguments"),()=>{};const i=y.subscribe(e,t);return this._manualStoreSubscriptions.push(i),i}_teardownManualStoreSubscriptions(){this._manualStoreSubscriptions.forEach(e=>{typeof e=="function"&&e()}),this._manualStoreSubscriptions=[]}addEventListener(e,t,i,a={}){if(!e||!t||!i){console.warn("[Component] addEventListener: Invalid arguments");return}e.addEventListener(t,i,a),this._listeners.push({element:e,event:t,handler:i,options:a})}removeEventListener(e,t,i){if(!e||!t||!i)return;e.removeEventListener(t,i);const a=this._listeners.findIndex(n=>n.element===e&&n.event===t&&n.handler===i);a!==-1&&this._listeners.splice(a,1)}addChild(e){return e instanceof q?this.children.includes(e)?(console.warn(`[Component] Child ${e.id} already exists`),this):(e.parent=this,this.children.push(e),this._childComponents.set(e.id,e),this.state.mounted&&!e.state.mounted&&e.mount(this.el),this.state.active&&!e.state.active&&e.activate(),this):(console.error("[Component] addChild: Invalid component instance"),this)}removeChild(e){const t=e instanceof q?e:this._childComponents.get(e);if(!t)return console.warn("[Component] removeChild: Component not found"),this;t.destroy();const i=this.children.indexOf(t);return i!==-1&&this.children.splice(i,1),this._childComponents.delete(t.id),this}getChild(e){return this._childComponents.get(e)}findChildrenByType(e){return this.children.filter(t=>t.type===e)}bindDeferredImages(e=this.el){if(!e)return;this._assetNodesMap||(this._assetNodesMap=new Map),this._assetSubscriptions||(this._assetSubscriptions=new Map),this._assetNodesMap.clear();const t=[];e.matches&&e.matches("[data-asset-key]")&&t.push(e);const i=new Set(this.children.map(a=>a.el).filter(Boolean));if(e.querySelectorAll&&e.querySelectorAll("[data-asset-key]").forEach(n=>{if(i.has(n))return;let c=!1,g=n.parentElement;for(;g&&g!==e&&g!==document.body;){if(i.has(g)){c=!0;break}g=g.parentElement}c||t.push(n)}),t.forEach(a=>{const n=a.getAttribute("data-asset-key");n&&(this._assetNodesMap.has(n)||this._assetNodesMap.set(n,new Set),this._assetNodesMap.get(n).add(a))}),this._assetSubscriptions)for(const[a,n]of this._assetSubscriptions.entries())this._assetNodesMap.has(a)||(W.unsubscribe(a,n),this._assetSubscriptions.delete(a));this._assetNodesMap.forEach((a,n)=>{if(this._assetSubscriptions.has(n)){const c=W.getLoadedAsset?W.getLoadedAsset(n):null;c&&this._applyAssetToNodes(n,c)}else{const c=`${this.id}::${n}`,g=W.requestAsset(n,{id:c,isValid:()=>this.state&&this.state.active&&!this.state.destroyed,onAssetReady:b=>{this._applyAssetToNodes(n,b)}});g&&g.subscribed&&this._assetSubscriptions.set(n,c),g&&(g.resource||g.fallback)&&this._applyAssetToNodes(n,g.resource||g.fallback)}})}unbindDeferredImages(){this._assetSubscriptions&&(this._assetSubscriptions.forEach((e,t)=>{W.unsubscribe(t,e)}),this._assetSubscriptions.clear(),this._assetNodesMap&&this._assetNodesMap.clear())}refreshDeferredImages(){this.bindDeferredImages(this.el)}_applyAssetToNodes(e,t){if(!t||!this._assetNodesMap)return;const i=this._assetNodesMap.get(e);if(!i)return;const a=[];i.forEach(n=>{n&&n.isConnected?n.tagName&&n.tagName.toUpperCase()==="IMG"&&(n.src=t):a.push(n)}),a.forEach(n=>i.delete(n))}$(e){return this.el?this.el.querySelector(e):null}$$(e){return this.el?this.el.querySelectorAll(e):[]}getInfo(){return{id:this.id,type:this.type,state:{...this.state},children:this.children.length,props:this.props,data:this.data}}log(){o.warn(`[Component:${this.type}]`,this.getInfo())}}class nt extends q{constructor(e={}){if(super(),this.label=e.label||"Info",this.ds=e.ds||"",this.type=e.type||"info",this.assetKey=e.assetKey||null,this.closable=e.closable!==!1,this.actionBtns=e.actionBtns||[],this.onCloseCallback=e.onClose||null,this.paramId=e.paramId||null,this.preserveFormatting=e.preserveFormatting===!0,this.paramId!==null){const t=_.tParam(this.paramId);t&&t.name?(this.label=t.name,this.ds=t.ds||this.ds,o.debug("Modal",`✅ Loaded translations for param ${this.paramId}: "${this.label}"`)):o.warn("Modal",`⚠️ No translation found for param ${this.paramId}, using fallback: "${this.label}"`)}this.enableI18n(()=>this._updateTranslations()),o.debug("Modal",`Created modal: "${this.label}" (type: ${this.type})`)}onCreate(){o.debug("Modal","onCreate")}onMount(){o.debug("Modal","onMount"),this._bindEvents()}onActivate(){o.debug("Modal","onActivate - showing modal"),this.el&&(this.el.classList.add("active"),document.body.style.overflow="hidden",this.el.querySelector(".modal-container")||o.warn("Modal","Modal container not found on activate"))}onDeactivate(){o.debug("Modal","onDeactivate - hiding modal"),this.el&&(this.el.classList.remove("active"),document.body.style.overflow="")}onDestroy(){o.debug("Modal","onDestroy"),document.body.style.overflow="",this.onCloseCallback=null,this.actionBtns=[]}_updateTranslations(){if(!this.el)return;if(this.paramId!==null){const i=_.tParam(this.paramId);i&&i.name&&(this.label=i.name,this.ds=i.ds||this.ds)}const e=this.el.querySelector(".modal-title"),t=this.el.querySelector(".modal-message");e&&(e.textContent=this.label),t&&(this.preserveFormatting?t.innerHTML=this.ds.replace(/\n/g,"<br>").trim():t.textContent=this.ds),o.debug("Modal",`Translations updated${this.paramId!==null?" for param "+this.paramId:""}: ${this.label}`)}_bindEvents(){if(!this.el)return;if(this.closable){this.el.addEventListener("click",i=>{i.target===this.el&&this.close()});const t=this.el.querySelector(".modal-close-btn");t&&t.addEventListener("click",()=>{this.close()})}this.el.querySelectorAll(".modal-action-btn").forEach((t,i)=>{const a=this.actionBtns[i];a&&typeof a.cb=="function"&&t.addEventListener("click",()=>{o.debug("Modal",`Action button clicked: ${a.label}`),a.cb(),this.close()})}),this.closable&&(this._handleEscKey=t=>{t.key==="Escape"&&this.close()},document.addEventListener("keydown",this._handleEscKey))}close(){o.debug("Modal","Closing modal"),typeof this.onCloseCallback=="function"&&this.onCloseCallback(),this.onDeactivate(),this._handleEscKey&&(document.removeEventListener("keydown",this._handleEscKey),this._handleEscKey=null),setTimeout(()=>{this.destroy()},300)}render(){const e=this._getIconHtml(),t=this.closable?this._getCloseBtnHtml():"",i=this._getActionBtnsHtml(),a=this.label.replace(/\n/g," ").trim(),n=this.preserveFormatting?this.ds.replace(/\n/g,"<br>").trim():this.ds.replace(/\n/g," ").trim();return`
      <div class="modal-backdrop">
        <div class="modal-container modal-${this.type}">
          ${t}
          
          <div class="modal-header">
            ${e}
            <h2 class="modal-title">${a}</h2>
          </div>
          
          <div class="modal-body">
            <p class="modal-message">${n}</p>
          </div>
          
          ${i}
        </div>
      </div>
    `}_getSuccessSvg(){return`
      <svg viewBox="0 0 48 48" fill="none" role="img" aria-label="Success">
        <circle cx="24" cy="24" r="22" stroke="currentColor" stroke-width="3" fill="none"/>
        <path d="M14 24l8 8 12-16" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `}_getErrorSvg(){return`
      <svg viewBox="0 0 48 48" fill="none" role="img" aria-label="Error">
        <circle cx="24" cy="24" r="22" stroke="currentColor" stroke-width="3" fill="none"/>
        <path d="M16 16l16 16M32 16L16 32" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>
      </svg>
    `}_getWarningSvg(){return`
      <svg viewBox="0 0 48 48" fill="none" role="img" aria-label="Warning">
        <path d="M24 4L44 40H4L24 4Z" stroke="currentColor" stroke-width="3" stroke-linejoin="round" fill="none"/>
        <path d="M24 18v10M24 32v2" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>
      </svg>
    `}_getIconHtml(){let e="";switch(this.type){case"success":e=this._getSuccessSvg();break;case"error":e=this._getErrorSvg();break;case"warning":e=this._getWarningSvg();break;case"info":e=`<img data-asset-key="${this.assetKey||"icon-setting"}" alt="${this.label}" draggable="false">`;break;default:e=`<img data-asset-key="${this.assetKey||"icon-setting"}" alt="${this.label}" draggable="false">`}return`
      <div class="modal-icon">
        ${e}
      </div>
    `}_getCloseBtnHtml(){return`
      <button class="modal-close-btn" aria-label="Close modal">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    `}_getActionBtnsHtml(){return!this.actionBtns||this.actionBtns.length===0?"":`
      <div class="modal-footer">
        ${this.actionBtns.map(t=>{const i=t.css||"modal-btn-primary",a=t.label||"OK";return`<button class="modal-action-btn ${i}">${a}</button>`}).join("")}
      </div>
    `}}const d={queue:[],currentModal:null,currentConfig:null,isVisible:!1,container:null,initialized:!1,keydownHandler:null};function rt(s){const e=new nt({label:s.label||s.title||"Info",ds:s.ds||s.message||"",type:s.type||"info",assetKey:s.assetKey||null,closable:s.closable!==!1,actionBtns:s.actionBtns||[],paramId:s.paramId||null,preserveFormatting:s.preserveFormatting===!0,onClose:()=>{if(typeof s.onClose=="function")try{s.onClose()}catch(t){console.error("❌ Errore in modal.onClose:",t)}he()}});return d.container||(d.container=document.getElementById("modal-manager-container"),d.container||(console.warn("⚠️ #modal-manager-container non trovato nell'HTML, lo creo dinamicamente"),d.container=document.createElement("div"),d.container.id="modal-manager-container",document.body.appendChild(d.container))),d.container.innerHTML="",e.mount(d.container),e}function de(){if(d.queue.length===0)return;d.queue.sort((t,i)=>(i.priority||0)-(t.priority||0));const s=d.queue.shift();d.currentConfig=s,d.isVisible=!0;const e=rt(s);if(d.currentModal=e,e.activate(),typeof s.onShow=="function")try{s.onShow()}catch(t){console.error("❌ Errore in modal.onShow:",t)}}function he(){!d.isVisible||!d.currentModal||(d.currentModal.deactivate(),d.isVisible=!1,setTimeout(()=>{d.currentModal&&(d.currentModal.destroy(),d.currentModal=null,d.currentConfig=null),d.queue.length>0&&de()},300))}function ot(s={}){!s.label&&!s.title&&!s.ds&&!s.message&&console.warn("⚠️ Modal senza titolo né messaggio");const e=s.priority||0;if(d.currentConfig){const t=d.currentConfig.priority||0;if(e>t){d.queue.push(d.currentConfig),d.queue.push(s),d.currentModal&&(d.currentModal.deactivate(),setTimeout(()=>{d.currentModal&&(d.currentModal.destroy(),d.currentModal=null,d.currentConfig=null,d.isVisible=!1),de()},300));return}}d.queue.push(s),d.queue.sort((t,i)=>(i.priority||0)-(t.priority||0)),d.currentModal||de()}function lt(){d.isVisible&&he()}function ct(){d.queue=[],d.isVisible&&d.currentModal&&(d.currentModal.deactivate(),setTimeout(()=>{d.currentModal&&(d.currentModal.destroy(),d.currentModal=null,d.currentConfig=null)},300),d.isVisible=!1)}function dt(){return d.currentModal}function ut(){return d.queue.length}function pt(){return d.isVisible}function gt(){d.initialized||(d.container=document.getElementById("modal-manager-container"),d.container||(console.warn("⚠️ #modal-manager-container non trovato nell'HTML, lo creo dinamicamente"),d.container=document.createElement("div"),d.container.id="modal-manager-container",document.body.appendChild(d.container)),d.keydownHandler=s=>{s.key==="Escape"&&d.isVisible&&d.currentModal&&he()},document.addEventListener("keydown",d.keydownHandler),d.initialized=!0)}function ht(){return{queueSize:d.queue.length,queue:d.queue.map(s=>({label:s.label||s.title,priority:s.priority})),current:d.currentConfig?{label:d.currentConfig.label||d.currentConfig.title,priority:d.currentConfig.priority,type:d.currentConfig.type}:null,currentModalInstance:d.currentModal?"Modal Component":null,isVisible:d.isVisible}}const me={init:gt,show:ot,hide:lt,clearAll:ct,getCurrentModal:dt,getQueueSize:ut,isVisible:pt,_debug:ht};class ft extends q{constructor(e={}){super(e),this.activeItemId=e.activeItemId||"dashboardPage",this.onItemClick=e.onItemClick||(()=>{}),this.onClose=e.onClose||(()=>{}),this.overlayEl=null,this.sidebarEl=null,this.closeBtn=null,o.debug("📂 Sidebar component created")}onBindEvents(){o.debug("[Sidebar onBindEvents] Binding events"),this.overlayEl=this.el.querySelector(".sidebar-overlay"),this.sidebarEl=this.el.querySelector(".sidebar"),this.closeBtn=this.el.querySelector(".sidebar-close-btn"),this.overlayEl&&this.overlayEl.addEventListener("click",()=>{this.close()}),this.closeBtn&&this.closeBtn.addEventListener("click",()=>{this.close()}),this._handleEscKey=e=>{e.key==="Escape"&&this.isOpen()&&this.close()},document.addEventListener("keydown",this._handleEscKey),this._bindMenuItems()}onActivate(){o.debug("[Sidebar onActivate] Activated")}onDestroy(){o.debug("[Sidebar onDestroy] Cleanup"),this._handleEscKey&&document.removeEventListener("keydown",this._handleEscKey)}render(){return`
      <div class="sidebar-wrapper">
        <div class="sidebar-overlay"></div>
        
        <div class="sidebar">
          <div class="sidebar-header">
            <div class="sidebar-brand">ECU SIMULATOR</div>
            
            <button class="sidebar-close-btn" aria-label="Close menu">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
          </div>
          
          <div class="sidebar-content">
            <nav class="sidebar-menu">
              ${this._renderMenuItems()}
            </nav>
          </div>
          
          <div class="sidebar-footer">
            <div class="sidebar-version">ECU Dev Board HIL</div>
          </div>
        </div>
      </div>
    `}_renderMenuItems(){return[{id:"dashboardPage",label:"Dashboard",icon:"icon-thermo",route:"dashboardPage"},{id:"rpmSettingsPage",label:"RPM Override",icon:"icon-timer",route:"rpmSettingsPage"},{id:"tpsSettingsPage",label:"TPS Override",icon:"icon-fan",route:"tpsSettingsPage"},{id:"egtSettingsPage",label:"EGT Override",icon:"icon-humidity",route:"egtSettingsPage"}].map(t=>`
        <div class="sidebar-item ${t.id===this.activeItemId?"active":""}" 
             data-menu-id="${t.id}" 
             data-route="${t.route}">
          <div class="sidebar-item-icon">
            <img data-asset-key="${t.icon}" alt="${t.label}" />
          </div>
          <span class="sidebar-item-label">${t.label}</span>
        </div>
      `).join("")}_bindMenuItems(){this.el.querySelectorAll(".sidebar-item[data-menu-id]").forEach(t=>{t.addEventListener("click",()=>{const i=t.getAttribute("data-menu-id"),a=t.getAttribute("data-route");o.debug(`[Sidebar] Item clicked: ${i} → ${a}`),this.onItemClick({menuId:i,route:a,element:t})})})}open(){this.isOpen()||(this.overlayEl&&this.overlayEl.classList.add("active"),this.sidebarEl&&this.sidebarEl.classList.add("active"))}close(){this.isOpen()&&(this.overlayEl&&this.overlayEl.classList.remove("active"),this.sidebarEl&&this.sidebarEl.classList.remove("active"),this.onClose())}toggle(){this.isOpen()?this.close():this.open()}isOpen(){return this.sidebarEl&&this.sidebarEl.classList.contains("active")}setActiveItem(e){if(this.activeItemId=String(e),!this.el)return;this.el.querySelectorAll(".sidebar-item").forEach(i=>{i.getAttribute("data-menu-id")===String(e)?i.classList.add("active"):i.classList.remove("active")})}}const C={sidebar:null,activeItemId:null,navigatorManager:null,initialized:!1};function vt({menuId:s,route:e}){o.debug(`[SidebarManager] Menu clicked: ${s} → ${e}`),e&&C.navigatorManager&&C.navigatorManager.navigateTo(e),Le(s),Ae()}function mt(){o.debug("[SidebarManager] Sidebar closed")}function bt(){if(!C.sidebar){o.warn("[SidebarManager] Sidebar component not initialized");return}C.sidebar.open(),o.info("📂 Sidebar opened")}function Ae(){if(!C.sidebar){o.warn("[SidebarManager] Sidebar component not initialized");return}C.sidebar.close(),o.info("📁 Sidebar closed")}function Et(){if(!C.sidebar){o.warn("[SidebarManager] Sidebar component not initialized");return}C.sidebar.toggle()}function Le(s){C.activeItemId=s,C.sidebar&&C.sidebar.setActiveItem(s),o.debug(`✨ Sidebar active menu: "${s}"`)}function Me(){return C.sidebar?C.sidebar.isOpen():!1}function St(){return C.activeItemId}function yt(){if(C.initialized){o.warn("[SidebarManager] already initialized — skipping duplicate init");return}o.info("📂 SidebarManager initializing..."),C.sidebar=new ft({activeItemId:C.activeItemId,onItemClick:vt,onClose:mt});let s=document.getElementById("sidebar-container");s||(s=document.createElement("div"),s.id="sidebar-container",document.body.appendChild(s),o.debug("[SidebarManager] Created sidebar-container")),C.sidebar.mount(s),C.sidebar.bindEvents(),C.sidebar.activate(),o.info("✅ SidebarManager initialized"),C.initialized=!0}function Tt(s){if(!s){o.warn("[SidebarManager] NavigatorManager not provided, navigation disabled");return}C.navigatorManager=s,o.debug("🔗 Sidebar navigation linked to NavigatorManager")}function Ct(){return{isOpen:Me(),activeItemId:C.activeItemId,sidebarPhase:C.sidebar?C.sidebar.phase:"not-created"}}const re={init:yt,open:bt,close:Ae,toggle:Et,setActiveItem:Le,isOpen:Me,getActiveItem:St,setupNavigation:Tt,_debug:Ct};function kt(){return localStorage.getItem("theme")||"light"}function It(s){localStorage.setItem("theme",s)}function _t(s){document.documentElement.setAttribute("data-theme",s)}function At(s){return s==="light"?"dark":"light"}function Lt(s,e){if(!s){console.warn("[func.updateThemeIcon] Container is null!");return}const t=s.querySelector(".theme-icon-light"),i=s.querySelector(".theme-icon-dark");if(!t||!i){console.warn("[TopBar/func] Theme icons not found");return}e==="light"?(t.style.display="block",i.style.display="none"):(t.style.display="none",i.style.display="block")}class Mt extends q{constructor(e={}){e.bindings||(e.bindings={socketStatus:"socket.state"}),super(e),this.onThemeToggle=e.onThemeToggle||null,this.onMenuClick=e.onMenuClick||null,this._currentTheme=kt()}onMount(){this._setupEventListeners(),this._updateThemeIcon(),this._updateConnectionStatus(this.data.socketStatus)}onDataChange(e,t){e==="socketStatus"&&this._updateConnectionStatus(t)}render(){const e=this._currentTheme==="light";return`
      <div class="top-bar-content">
        <div class="top-bar-left">
          <div class="product-info">
            <div class="product-name">ECU TEST CENTER</div>
          </div>
        </div>
        
        <div class="top-bar-right">
          <!-- Connection Status Badge -->
          <div class="connection-status-badge" data-connection-status>DISCONNECTED</div>

          <button class="icon-btn" data-theme-toggle id="theme-toggle" title="Toggle Theme">
            <img 
              data-asset-key="icon-sun" 
              alt="Light" 
              class="theme-icon theme-icon-light"
              style="${e?"":"display: none;"}"
              draggable="false"
            >
            <img 
              data-asset-key="icon-moon" 
              alt="Dark" 
              class="theme-icon theme-icon-dark" 
              style="${e?"display: none;":""}"
              draggable="false"
            >
          </button>
          <button class="icon-btn" data-menu-toggle id="menu-btn" title="Menu">
            <img 
              data-asset-key="icon-hamburger-menu" 
              alt="Menu"
              draggable="false"
            >
          </button>
        </div>
      </div>
    `.trim()}_setupEventListeners(){const e=this.$("[data-theme-toggle]");e&&this.addEventListener(e,"click",()=>this._handleThemeToggle());const t=this.$("[data-menu-toggle]");t&&this.addEventListener(t,"click",()=>this._handleMenuClick())}_handleThemeToggle(){const e=At(this._currentTheme);this._currentTheme=e,_t(e),It(e),this._updateThemeIcon(),typeof this.onThemeToggle=="function"&&this.onThemeToggle(e)}_handleMenuClick(){typeof this.onMenuClick=="function"&&this.onMenuClick()}_updateConnectionStatus(e){const t=this.$("[data-connection-status]");if(!t)return;const i=e||"disconnected";t.textContent=i.toUpperCase(),t.className=`connection-status-badge ${i.toLowerCase()}`}_updateThemeIcon(){Lt(this.el,this._currentTheme)}}const Dt="modulepreload",Ot=function(s,e){return new URL(s,e).href},be={},oe=function(e,t,i){let a=Promise.resolve();if(t&&t.length>0){let m=function(E){return Promise.all(E.map(S=>Promise.resolve(S).then(f=>({status:"fulfilled",value:f}),f=>({status:"rejected",reason:f}))))};const c=document.getElementsByTagName("link"),g=document.querySelector("meta[property=csp-nonce]"),b=(g==null?void 0:g.nonce)||(g==null?void 0:g.getAttribute("nonce"));a=m(t.map(E=>{if(E=Ot(E,i),E in be)return;be[E]=!0;const S=E.endsWith(".css"),f=S?'[rel="stylesheet"]':"";if(i)for(let r=c.length-1;r>=0;r--){const u=c[r];if(u.href===E&&(!S||u.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${E}"]${f}`))return;const l=document.createElement("link");if(l.rel=S?"stylesheet":Dt,S||(l.as="script"),l.crossOrigin="",l.href=E,b&&l.setAttribute("nonce",b),document.head.appendChild(l),S)return new Promise((r,u)=>{l.addEventListener("load",r),l.addEventListener("error",()=>u(new Error(`Unable to preload CSS for ${E}`)))})}))}function n(c){const g=new Event("vite:preloadError",{cancelable:!0});if(g.payload=c,window.dispatchEvent(g),!g.defaultPrevented)throw c}return a.then(c=>{for(const g of c||[])g.status==="rejected"&&n(g.reason);return e().catch(n)})};let ee=!1,K=null,le=0;function Rt(s,e){s.set(e.TELEMETRY.RPM,1200),s.set(e.TELEMETRY.TPS,0),s.set(e.TELEMETRY.EGT,20),s.set(e.TELEMETRY.ECU_ADVANCE,15),s.set(e.TELEMETRY.SPARK_DETECTED,!0),s.set(e.OVERRIDES.TPS.ACTIVE,!1),s.set(e.OVERRIDES.TPS.VALUE,0),s.set(e.OVERRIDES.EGT.ACTIVE,!1),s.set(e.OVERRIDES.EGT.VALUE,20),s.set(e.OVERRIDES.RPM.ACTIVE,!1),s.set(e.OVERRIDES.RPM.VALUE,1200),s.set(e.OVERRIDES.EGT_FAULT.ACTIVE,!1),s.set(e.SOCKET.STATE,"connected")}function wt(s,e){le=0;const t=setInterval(()=>{var w,R,$,x,H,U,Y,z,Q;le++;const i=(w=s.get(e.OVERRIDES.TPS.ACTIVE))!=null?w:!1,a=(R=s.get(e.OVERRIDES.TPS.VALUE))!=null?R:0,n=($=s.get(e.OVERRIDES.RPM.ACTIVE))!=null?$:!1,c=(x=s.get(e.OVERRIDES.RPM.VALUE))!=null?x:1200,g=(H=s.get(e.OVERRIDES.EGT.ACTIVE))!=null?H:!1,b=(U=s.get(e.OVERRIDES.EGT.VALUE))!=null?U:20,m=(Y=s.get(e.OVERRIDES.EGT_FAULT.ACTIVE))!=null?Y:!1;let E=(z=s.get(e.TELEMETRY.RPM))!=null?z:1200,S=(Q=s.get(e.TELEMETRY.EGT))!=null?Q:20;const f=20+10*Math.sin(le*.0628),l=i?a:f;let r=E;if(n)r=c;else{const ie=1200+l/100*16800;r+=(ie-r)*.2}r<0&&(r=0),r>18e3&&(r=18e3);let u=S;if(g)u=b;else if(m)u+=(850-u)*.4;else{let F;ee?F=20:F=20+l*4+r*.03,u+=(F-u)*.1}u<20&&(u=20),u>1e3&&(u=1e3);const v=r>100&&!ee,A=15+r/1e3*1.2;s.set(e.TELEMETRY.TPS,Number(l.toFixed(1))),s.set(e.TELEMETRY.RPM,Number(r.toFixed(1))),s.set(e.TELEMETRY.EGT,Number(u.toFixed(1))),s.set(e.TELEMETRY.ECU_ADVANCE,Number(A.toFixed(2))),s.set(e.TELEMETRY.SPARK_DETECTED,v)},100);return()=>{clearInterval(t),K&&clearTimeout(K)}}function Nt(s,e,t){try{const i=JSON.parse(s),{cmd:a,param:n,active:c,value:g,fault:b}=i;o.debug("[MockEmulator] Received command:",i),a==="toggle_override"?n==="tps"?e.set(t.OVERRIDES.TPS.ACTIVE,!!c):n==="egt"?e.set(t.OVERRIDES.EGT.ACTIVE,!!c):n==="rpm"&&e.set(t.OVERRIDES.RPM.ACTIVE,!!c):a==="set_value"?n==="tps"?e.set(t.OVERRIDES.TPS.VALUE,Number(g)):n==="egt"?e.set(t.OVERRIDES.EGT.VALUE,Number(g)):n==="rpm"&&e.set(t.OVERRIDES.RPM.VALUE,Number(g)):a==="inject_fault"?b==="egt_overheat"&&e.set(t.OVERRIDES.EGT_FAULT.ACTIVE,!!c):a==="qs_trigger"&&(ee=!0,e.set(t.TELEMETRY.SPARK_DETECTED,!1),o.info("[MockEmulator] ⚡ Quick shift cut activated (80ms)"),K&&clearTimeout(K),K=setTimeout(()=>{ee=!1,e.set(t.TELEMETRY.SPARK_DETECTED,!0),o.info("[MockEmulator] ⚡ Quick shift cut ended")},80))}catch(i){o.error("[MockEmulator] Failed to apply command effect",i)}}function Pt(){oe(async()=>{const{Socket:s}=await Promise.resolve().then(()=>We);return{Socket:s}},void 0,import.meta.url).then(({Socket:s})=>{const e=s.send;if(e&&e._isMockWrapped)return;const t=i=>{oe(async()=>{const{Store:a}=await Promise.resolve().then(()=>xe);return{Store:a}},void 0,import.meta.url).then(({Store:a})=>{oe(async()=>{const{Paths:n}=await Promise.resolve().then(()=>qe);return{Paths:n}},void 0,import.meta.url).then(({Paths:n})=>{Nt(i,a,n)})});try{e.call(s,i)}catch(a){}};t._isMockWrapped=!0,s.send=t}).catch(()=>{})}Pt();class te extends q{constructor(e={}){e.el||(e.el=`#${e.id}`),super(e),this.pageId=this.id,this.title=e.title||"Untitled Page",this.icon=e.icon||null,this.showBackButton=e.showBackButton!==void 0?e.showBackButton:!0,this.onBackButton=e.onBackButton||null,this.isHomePage=!1,this.navigationDepth=0,this.components={header:[],content:[],footer:[]}}onActivate(){if(super.onActivate(),this._updateHeader(),this.el){const e=this.el.querySelector(".content-area");e&&(e.scrollTop=0)}}onDeactivate(){if(super.onDeactivate(),this.el){const e=this.el.querySelector(".content-area");e&&(this._scrollPosition=e.scrollTop)}}createSkeleton(){const e=document.createElement("div");e.className="page left",e.id=this.pageId;const t=document.createElement("div");return t.className="content-area",t.innerHTML=this.renderContent(),e.appendChild(t),this.el=e,this.phase="rendered",this.state.mounted=!0,this.onMount(),this._setupI18nBinding(),e}render(){return`
      <div id="${this.pageId}" class="page">
        ${this.showBackButton?this._renderHeader():""}
        <div class="content-area">
          ${this.renderContent()}
        </div>
      </div>
    `}_renderHeader(){return`
      <div class="sub-header">
        <button class="back-btn" data-page-back="${this.pageId}" aria-label="Indietro">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
        </button>
        <h2 class="sub-header-title">${this.title}</h2>
      </div>
    `}renderContent(){return"<p>Page content goes here</p>"}_updateHeader(){if(!this.showBackButton||!this.el)return;const e=this.el.querySelector(".sub-header-title");e&&(e.textContent=this.title)}setTitle(e){this.title=e,this.state.active&&this._updateHeader()}setParameter(e){this.param=e}addComponent(e,t="content"){if(!this.components[t])return console.warn(`[Page] Invalid area: ${t}`),this;if(this.components[t].push(e),this.addChild(e),this.state.mounted){const i=this._getAreaContainer(t);i&&e.mount(i)}return this}_getAreaContainer(e){if(!this.el)return null;switch(e){case"header":return this.el.querySelector(".sub-header");case"content":return this.el.querySelector(".content-area");case"footer":return this.el.querySelector(".page-footer");default:return this.el.querySelector(".content-area")}}clearComponents(){Object.values(this.components).forEach(e=>{e.forEach(t=>{this.removeChild(t)})}),this.components={header:[],content:[],footer:[]}}showLoading(e="Caricamento..."){const t=this._getAreaContainer("content");if(!t)return;const i=document.createElement("div");i.className="page-loading",i.innerHTML=`
      <div class="spinner"></div>
      <p>${e}</p>
    `,i.dataset.pageLoading="true",t.appendChild(i)}hideLoading(){const e=this._getAreaContainer("content");if(!e)return;const t=e.querySelector('[data-page-loading="true"]');t&&t.remove()}showError(e,t=null){const i=this._getAreaContainer("content");if(!i)return;const a=document.createElement("div");a.className="page-error",a.innerHTML=`
      <div class="error-icon">⚠️</div>
      <p class="error-message">${e}</p>
      ${t?'<button class="error-retry-btn">Riprova</button>':""}
    `,a.dataset.pageError="true",t&&a.querySelector(".error-retry-btn").addEventListener("click",()=>{this.hideError(),t()}),i.appendChild(a)}hideError(){const e=this._getAreaContainer("content");if(!e)return;const t=e.querySelector('[data-page-error="true"]');t&&t.remove()}restoreScrollPosition(){if(this._scrollPosition!==void 0&&this.el){const e=this.el.querySelector(".content-area");e&&(e.scrollTop=this._scrollPosition)}}handleBack(){return typeof this.onBackButton=="function"?this.onBackButton():!0}canLeave(){return!0}canEnter(){return!0}getInfo(){return{...super.getInfo(),pageId:this.pageId,title:this.title,isHomePage:this.isHomePage,navigationDepth:this.navigationDepth,componentCounts:{header:this.components.header.length,content:this.components.content.length,footer:this.components.footer.length}}}}class Bt extends te{constructor(e={}){super({id:"dashboardPage",title:"ECU Dashboard",showBackButton:!1,bindings:{rpm:"telemetry.rpm",tps:"telemetry.tps",egt:"telemetry.egt",ecu_advance:"telemetry.ecu_advance",spark_detected:"telemetry.spark_detected",tpsOverrideActive:"overrides.tps.active",egtOverrideActive:"overrides.egt.active",rpmOverrideActive:"overrides.rpm.active",egtFaultActive:"overrides.egt_fault.active"},...e})}onBindEvents(){o.debug("DashboardPage","onBindEvents");const e=this.el.querySelector("#rpm-gauge-trigger");e&&e.addEventListener("click",()=>{V.navigateTo("rpmSettingsPage")});const t=this.el.querySelector("#tps-card");t&&t.addEventListener("click",()=>{V.navigateTo("tpsSettingsPage")});const i=this.el.querySelector("#egt-card");i&&i.addEventListener("click",()=>{V.navigateTo("egtSettingsPage")});const a=this.el.querySelector("#qs-trigger-btn");a&&a.addEventListener("click",n=>{n.stopPropagation(),a.classList.add("active"),setTimeout(()=>a.classList.remove("active"),150),M.triggerQs()})}onActivate(){super.onActivate(),o.debug("DashboardPage","Activated"),this._updateAll()}onDataChange(e,t){if(this.el)switch(e){case"rpm":this._updateRpmGauge(t);break;case"tps":this._updateTpsCard(t);break;case"egt":this._updateEgtCard(t);break;case"ecu_advance":this._updateIgnitionAdvance(t);break;case"spark_detected":this._updateSparkStatus(t);break;case"tpsOverrideActive":this._updateTpsOverrideState(t);break;case"egtOverrideActive":this._updateEgtOverrideState(t);break;case"rpmOverrideActive":this._updateRpmOverrideState(t);break;case"egtFaultActive":this._updateEgtFaultState(t);break}}renderContent(){return`
      <div class="dashboard-container">
        
        <!-- RPM HERO SECTION -->
        <div class="hero-section">
          <div class="rpm-gauge-wrapper interactive" id="rpm-gauge-trigger" title="Configure RPM Overrides">
            <div class="rpm-gauge-container">
              <svg class="rpm-gauge-svg" viewBox="0 0 200 200">
                <!-- Gauge track -->
                <path class="gauge-track" d="M 40 160 A 80 80 0 1 1 160 160" fill="none" stroke-linecap="round"/>
                <!-- Gauge active fill -->
                <path class="gauge-fill" id="rpm-gauge-fill" d="M 40 160 A 80 80 0 1 1 160 160" fill="none" stroke-linecap="round" stroke-dasharray="377" stroke-dashoffset="377"/>
              </svg>
              <div class="gauge-text-container">
                <div class="gauge-value" id="rpm-gauge-value">0</div>
                <div class="gauge-unit">RPM</div>
                <div class="gauge-badge" id="rpm-override-badge">PHYSICAL</div>
              </div>
            </div>
          </div>
        </div>

        <!-- QUICK-SHIFT TRIGGER SECTION -->
        <div class="qs-trigger-section">
          <button class="qs-btn" id="qs-trigger-btn">
            <span class="qs-icon">⚡</span>
            <span class="qs-text">TRIGGER QUICK-SHIFT</span>
          </button>
        </div>

        <!-- METRICS GRID -->
        <div class="metrics-grid">
          
          <!-- TPS CARD -->
          <div class="metric-card interactive" id="tps-card" title="Configure TPS Overrides">
            <div class="metric-header">
              <span class="metric-title">Throttle Position (TPS)</span>
              <span class="status-indicator" id="tps-override-indicator">PHYSICAL</span>
            </div>
            <div class="metric-body">
              <span class="metric-value" id="tps-value">0.0</span>
              <span class="metric-unit">%</span>
            </div>
            <div class="metric-footer" id="tps-card-footer">Physical Sensor</div>
          </div>

          <!-- EGT CARD -->
          <div class="metric-card interactive" id="egt-card" title="Configure EGT Overrides">
            <div class="metric-header">
              <span class="metric-title">Exhaust Gas Temp (EGT)</span>
              <span class="status-indicator" id="egt-override-indicator">PHYSICAL</span>
            </div>
            <div class="metric-body">
              <span class="metric-value" id="egt-value">20.0</span>
              <span class="metric-unit">°C</span>
            </div>
            <div class="metric-footer" id="egt-card-footer">Ambient Temp</div>
          </div>

          <!-- IGNITION ADVANCE CARD -->
          <div class="metric-card">
            <div class="metric-header">
              <span class="metric-title">Ignition Advance</span>
            </div>
            <div class="metric-body">
              <span class="metric-value" id="advance-value">0.00</span>
              <span class="metric-unit">° BTDC</span>
            </div>
            <div class="metric-footer">Computed Timing Angle</div>
          </div>

          <!-- SPARK DETECTED CARD -->
          <div class="metric-card" id="spark-card">
            <div class="metric-header">
              <span class="metric-title">Spark Detected</span>
            </div>
            <div class="spark-status-body">
              <span class="spark-led" id="spark-led"></span>
              <span class="spark-text" id="spark-status-text">NO SPARK</span>
            </div>
            <div class="metric-footer">Live CDI Pulse Capture</div>
          </div>

        </div>

      </div>
    `}_updateAll(){this._updateRpmGauge(this.data.rpm||0),this._updateTpsCard(this.data.tps||0),this._updateEgtCard(this.data.egt||20),this._updateIgnitionAdvance(this.data.ecu_advance||0),this._updateSparkStatus(this.data.spark_detected),this._updateTpsOverrideState(this.data.tpsOverrideActive),this._updateEgtOverrideState(this.data.egtOverrideActive),this._updateRpmOverrideState(this.data.rpmOverrideActive),this._updateEgtFaultState(this.data.egtFaultActive)}_updateRpmGauge(e){const t=this.el.querySelector("#rpm-gauge-value"),i=this.el.querySelector("#rpm-gauge-fill");if(t&&(t.textContent=Math.round(e).toLocaleString()),i){const g=377*(1-Math.min(Math.max(e/18e3,0),1));i.style.strokeDashoffset=g}}_updateTpsCard(e){const t=this.el.querySelector("#tps-value");t&&(t.textContent=Number(e).toFixed(1))}_updateEgtCard(e){const t=this.el.querySelector("#egt-value");t&&(t.textContent=Number(e).toFixed(1))}_updateIgnitionAdvance(e){const t=this.el.querySelector("#advance-value");t&&(t.textContent=Number(e).toFixed(2))}_updateSparkStatus(e){const t=this.el.querySelector("#spark-led"),i=this.el.querySelector("#spark-status-text");t&&(e?t.className="spark-led active pulsing":t.className="spark-led inactive"),i&&(i.textContent=e?"SPARK ACTIVE":"NO SPARK")}_updateTpsOverrideState(e){const t=this.el.querySelector("#tps-override-indicator"),i=this.el.querySelector("#tps-card-footer"),a=this.el.querySelector("#tps-card");t&&(t.textContent=e?"VIRTUAL":"PHYSICAL",t.className=e?"status-indicator active":"status-indicator"),i&&(i.textContent=e?"Manual Override Active":"Physical Sensor"),a&&(e?a.classList.add("override-active"):a.classList.remove("override-active"))}_updateEgtOverrideState(e){const t=this.el.querySelector("#egt-override-indicator"),i=this.el.querySelector("#egt-card-footer"),a=this.el.querySelector("#egt-card");t&&(t.textContent=e?"VIRTUAL":"PHYSICAL",t.className=e?"status-indicator active":"status-indicator"),i&&(this.data.egtFaultActive||(i.textContent=e?"Manual Override Active":"Physics Superloop")),a&&(e?a.classList.add("override-active"):a.classList.remove("override-active"))}_updateRpmOverrideState(e){const t=this.el.querySelector("#rpm-override-badge"),i=this.el.querySelector("#rpm-gauge-trigger");t&&(t.textContent=e?"OVERRIDDEN":"PHYSICAL",t.className=e?"gauge-badge active":"gauge-badge"),i&&(e?i.classList.add("override-active"):i.classList.remove("override-active"))}_updateEgtFaultState(e){const t=this.el.querySelector("#egt-card-footer"),i=this.el.querySelector("#egt-card");i&&(e?(i.classList.add("fault-active"),t&&(t.textContent="FAULT: OVERHEAT INJECTED")):(i.classList.remove("fault-active"),t&&(t.textContent=this.data.egtOverrideActive?"Manual Override Active":"Physics Superloop")))}}class fe extends q{constructor(e={}){super(e),this.title=e.title||"",this.menuId=e.menuId||null,this.onBack=e.onBack||null,this.backBtn=null,this.menuId!==null&&this.enableI18n(()=>this._updateLabels()),o.debug("[PageTopBar] Component created")}onCreate(){o.debug("[PageTopBar onCreate] Called")}onMount(){o.debug("[PageTopBar onMount] PageTopBar mounted"),this._bindEvents()}onBindEvents(){o.debug("[PageTopBar onBindEvents] Manual call - binding events"),this._bindEvents()}_bindEvents(){o.debug("[PageTopBar _bindEvents] Binding events"),this.backBtn=this.el.querySelector(".back-btn"),this.backBtn?(this.backBtn.addEventListener("click",()=>{o.debug("[PageTopBar] Back button clicked"),typeof this.onBack=="function"?(o.debug("[PageTopBar] Using custom onBack callback"),this.onBack()):(o.debug("[PageTopBar] Using default navigation (goBack)"),_e())}),o.debug("[PageTopBar] Back button listener attached")):o.warn("[PageTopBar] Back button not found in DOM")}onActivate(){o.debug("[PageTopBar onActivate] Called")}onDeactivate(){o.debug("[PageTopBar onDeactivate] Called")}onDestroy(){o.debug("[PageTopBar onDestroy] Cleanup")}render(){return`
      <div class="sub-header">
        <button class="back-btn" aria-label="Go back">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
        </button>
        <h1 class="sub-header-title">${this.title}</h1>
      </div>
    `}_updateLabels(){if(this.el&&this.menuId!==null){const e=_.tMenu(this.menuId);if(!e){o.warn("[PageTopBar] No translation found for menuId",this.menuId);return}this.title=e;const t=this.el.querySelector(".sub-header-title");t&&(t.textContent=this.title,o.debug(`[PageTopBar] Title updated to: ${this.title}`))}}setTitle(e){if(this.title=e,!this.el){o.warn("[PageTopBar] setTitle called before mount");return}const t=this.el.querySelector(".sub-header-title");t&&(t.textContent=e,o.debug(`[PageTopBar] Title updated to: ${e}`))}setMenuId(e){this.menuId=e,this.el&&!this._i18nEnabled&&this.menuId!==null?(this.enableI18n(()=>this._updateLabels()),o.debug(`[PageTopBar] menuId set to ${e}, i18n enabled`)):o.debug(`[PageTopBar] menuId set to ${e}`),this.el&&this.menuId!==null&&this._updateLabels()}setOnBack(e){typeof e=="function"&&(this.onBack=e,o.debug("[PageTopBar] onBack callback updated"))}}class $t extends te{constructor(e={}){super({id:"rpmSettingsPage",title:"RPM Configuration",showBackButton:!0,bindings:{rpm:"telemetry.rpm",rpmOverrideActive:"overrides.rpm.active",rpmOverrideValue:"overrides.rpm.value"},...e}),this.pageTopBar=null}createSkeleton(){const e=super.createSkeleton(),t=this.el.querySelector("#page-top-bar-container");return t&&(this.pageTopBar=new fe({title:_.t("ui.rpmOverrideTitle")}),this.pageTopBar.mount(t)),e}onBindEvents(){o.debug("RpmSettingsPage","onBindEvents");const e=this.el.querySelector("#rpm-override-toggle"),t=this.el.querySelector("#rpm-slider"),i=this.el.querySelectorAll(".preset-badge");e&&e.addEventListener("change",a=>{const n=a.target.checked;M.toggleOverride("rpm",n),this._updateUIState(n)}),t&&t.addEventListener("input",a=>{const n=parseInt(a.target.value);this._updateSliderLabel(n),M.setValue("rpm",n)}),i.forEach(a=>{a.addEventListener("click",()=>{const n=parseInt(a.getAttribute("data-value"));e&&!e.checked&&(e.checked=!0,M.toggleOverride("rpm",!0),this._updateUIState(!0)),t&&(t.value=n),this._updateSliderLabel(n),M.setValue("rpm",n)})})}onActivate(){super.onActivate(),o.debug("RpmSettingsPage","Activated"),this._syncState()}onDataChange(e,t){if(this.el){if(e==="rpmOverrideActive"){const i=this.el.querySelector("#rpm-override-toggle");i&&(i.checked=!!t),this._updateUIState(!!t)}else if(e==="rpmOverrideValue"){const i=this.el.querySelector("#rpm-slider");i&&!this._isUserInteractingWithSlider()&&(i.value=t,this._updateSliderLabel(t))}else if(e==="rpm"){const i=this.el.querySelector("#rpm-live-value");i&&(i.textContent=Math.round(t).toLocaleString())}}}renderContent(){return`
      <div id="page-top-bar-container"></div>

      <div class="settings-content">
        <div class="info-card">
          <p class="description">${_.t("ui.rpmOverrideDesc")}</p>
        </div>

        <!-- OVERRIDE TOGGLE CARD -->
        <div class="settings-card">
          <div class="toggle-container">
            <div class="toggle-details">
              <span class="toggle-title">${_.t("ui.overrideToggle")}</span>
              <span class="toggle-description">Bypasses the physical potentiometer TPS kinematics</span>
            </div>
            <label class="switch">
              <input type="checkbox" id="rpm-override-toggle">
              <span class="switch-slider"></span>
            </label>
          </div>
        </div>

        <!-- SLIDER CONTROL CARD -->
        <div class="settings-card slider-card disabled" id="rpm-slider-card">
          <div class="slider-header">
            <span class="slider-title">${_.t("ui.targetRpm")}</span>
            <span class="slider-value" id="rpm-slider-value">1,200</span>
            <span class="slider-unit">RPM</span>
          </div>
          <div class="slider-container">
            <input type="range" id="rpm-slider" min="0" max="18000" step="100" value="1200">
            <div class="slider-ticks">
              <span>0</span>
              <span>4.5k</span>
              <span>9k</span>
              <span>13.5k</span>
              <span>18k</span>
            </div>
          </div>
        </div>

        <!-- QUICK PRESETS CARD -->
        <div class="settings-card">
          <div class="card-header-simple">
            <span class="card-title">${_.t("ui.presets")}</span>
          </div>
          <div class="presets-grid">
            <button class="preset-badge" data-value="1200">
              <span class="preset-name">Idle</span>
              <span class="preset-val">1.2k RPM</span>
            </button>
            <button class="preset-badge" data-value="3000">
              <span class="preset-name">Cruising</span>
              <span class="preset-val">3k RPM</span>
            </button>
            <button class="preset-badge" data-value="6000">
              <span class="preset-name">High</span>
              <span class="preset-val">6k RPM</span>
            </button>
            <button class="preset-badge" data-value="12000">
              <span class="preset-name">Racing</span>
              <span class="preset-val">12k RPM</span>
            </button>
            <button class="preset-badge" data-value="18000">
              <span class="preset-name">Redline</span>
              <span class="preset-val">18k RPM</span>
            </button>
          </div>
        </div>

        <!-- LIVE TELEMETRY CARD -->
        <div class="settings-card">
          <div class="live-status-container">
            <span class="live-status-title">Live Engine Speed</span>
            <div class="live-status-details">
              <span class="live-status-value" id="rpm-live-value">0</span>
              <span class="live-status-unit">RPM</span>
            </div>
          </div>
        </div>

      </div>
    `}_syncState(){var c,g;const e=(c=this.data.rpmOverrideActive)!=null?c:!1,t=(g=this.data.rpmOverrideValue)!=null?g:1200,i=this.el.querySelector("#rpm-override-toggle"),a=this.el.querySelector("#rpm-slider"),n=this.el.querySelector("#rpm-live-value");i&&(i.checked=e),a&&(a.value=t,this._updateSliderLabel(t)),n&&(n.textContent=Math.round(this.data.rpm||0).toLocaleString()),this._updateUIState(e)}_updateUIState(e){const t=this.el.querySelector("#rpm-slider-card"),i=this.el.querySelector("#rpm-slider");t&&(e?t.classList.remove("disabled"):t.classList.add("disabled")),i&&(i.disabled=!e)}_updateSliderLabel(e){const t=this.el.querySelector("#rpm-slider-value");t&&(t.textContent=Math.round(e).toLocaleString())}_isUserInteractingWithSlider(){const e=this.el.querySelector("#rpm-slider");return e&&document.activeElement===e}onDestroy(){super.onDestroy(),this.pageTopBar&&(this.pageTopBar.destroy(),this.pageTopBar=null)}}class xt extends te{constructor(e={}){super({id:"tpsSettingsPage",title:"TPS Configuration",showBackButton:!0,bindings:{tps:"telemetry.tps",tpsOverrideActive:"overrides.tps.active",tpsOverrideValue:"overrides.tps.value"},...e}),this.pageTopBar=null}createSkeleton(){const e=super.createSkeleton(),t=this.el.querySelector("#page-top-bar-container");return t&&(this.pageTopBar=new fe({title:_.t("ui.tpsOverrideTitle")}),this.pageTopBar.mount(t)),e}onBindEvents(){o.debug("TpsSettingsPage","onBindEvents");const e=this.el.querySelector("#tps-override-toggle"),t=this.el.querySelector("#tps-slider"),i=this.el.querySelectorAll(".preset-badge");e&&e.addEventListener("change",a=>{const n=a.target.checked;M.toggleOverride("tps",n),this._updateUIState(n)}),t&&t.addEventListener("input",a=>{const n=parseFloat(a.target.value);this._updateSliderLabel(n),M.setValue("tps",n)}),i.forEach(a=>{a.addEventListener("click",()=>{const n=parseFloat(a.getAttribute("data-value"));e&&!e.checked&&(e.checked=!0,M.toggleOverride("tps",!0),this._updateUIState(!0)),t&&(t.value=n),this._updateSliderLabel(n),M.setValue("tps",n)})})}onActivate(){super.onActivate(),o.debug("TpsSettingsPage","Activated"),this._syncState()}onDataChange(e,t){if(this.el){if(e==="tpsOverrideActive"){const i=this.el.querySelector("#tps-override-toggle");i&&(i.checked=!!t),this._updateUIState(!!t)}else if(e==="tpsOverrideValue"){const i=this.el.querySelector("#tps-slider");i&&!this._isUserInteractingWithSlider()&&(i.value=t,this._updateSliderLabel(t))}else if(e==="tps"){const i=this.el.querySelector("#tps-live-value");i&&(i.textContent=Number(t).toFixed(1))}}}renderContent(){return`
      <div id="page-top-bar-container"></div>

      <div class="settings-content">
        <div class="info-card">
          <p class="description">${_.t("ui.tpsOverrideDesc")}</p>
        </div>

        <!-- OVERRIDE TOGGLE CARD -->
        <div class="settings-card">
          <div class="toggle-container">
            <div class="toggle-details">
              <span class="toggle-title">${_.t("ui.overrideToggle")}</span>
              <span class="toggle-description">Bypasses the physical potentiometer inputs</span>
            </div>
            <label class="switch">
              <input type="checkbox" id="tps-override-toggle">
              <span class="switch-slider"></span>
            </label>
          </div>
        </div>

        <!-- SLIDER CONTROL CARD -->
        <div class="settings-card slider-card disabled" id="tps-slider-card">
          <div class="slider-header">
            <span class="slider-title">${_.t("ui.targetTps")}</span>
            <span class="slider-value" id="tps-slider-value">0.0</span>
            <span class="slider-unit">%</span>
          </div>
          <div class="slider-container">
            <input type="range" id="tps-slider" min="0" max="100" step="1" value="0">
            <div class="slider-ticks">
              <span>0% (Idle)</span>
              <span>25%</span>
              <span>50%</span>
              <span>75%</span>
              <span>100% (WOT)</span>
            </div>
          </div>
        </div>

        <!-- QUICK PRESETS CARD -->
        <div class="settings-card">
          <div class="card-header-simple">
            <span class="card-title">${_.t("ui.presets")}</span>
          </div>
          <div class="presets-grid">
            <button class="preset-badge" data-value="0">
              <span class="preset-name">0%</span>
              <span class="preset-val">Closed</span>
            </button>
            <button class="preset-badge" data-value="25">
              <span class="preset-name">25%</span>
              <span class="preset-val">Low</span>
            </button>
            <button class="preset-badge" data-value="50">
              <span class="preset-name">50%</span>
              <span class="preset-val">Half</span>
            </button>
            <button class="preset-badge" data-value="75">
              <span class="preset-name">75%</span>
              <span class="preset-val">High</span>
            </button>
            <button class="preset-badge" data-value="100">
              <span class="preset-name">100%</span>
              <span class="preset-val">WOT</span>
            </button>
          </div>
        </div>

        <!-- LIVE TELEMETRY CARD -->
        <div class="settings-card">
          <div class="live-status-container">
            <span class="live-status-title">Live Throttle Position</span>
            <div class="live-status-details">
              <span class="live-status-value" id="tps-live-value">0.0</span>
              <span class="live-status-unit">%</span>
            </div>
          </div>
        </div>

      </div>
    `}_syncState(){var c,g;const e=(c=this.data.tpsOverrideActive)!=null?c:!1,t=(g=this.data.tpsOverrideValue)!=null?g:0,i=this.el.querySelector("#tps-override-toggle"),a=this.el.querySelector("#tps-slider"),n=this.el.querySelector("#tps-live-value");i&&(i.checked=e),a&&(a.value=t,this._updateSliderLabel(t)),n&&(n.textContent=Number(this.data.tps||0).toFixed(1)),this._updateUIState(e)}_updateUIState(e){const t=this.el.querySelector("#tps-slider-card"),i=this.el.querySelector("#tps-slider");t&&(e?t.classList.remove("disabled"):t.classList.add("disabled")),i&&(i.disabled=!e)}_updateSliderLabel(e){const t=this.el.querySelector("#tps-slider-value");t&&(t.textContent=Number(e).toFixed(1))}_isUserInteractingWithSlider(){const e=this.el.querySelector("#tps-slider");return e&&document.activeElement===e}onDestroy(){super.onDestroy(),this.pageTopBar&&(this.pageTopBar.destroy(),this.pageTopBar=null)}}class qt extends te{constructor(e={}){super({id:"egtSettingsPage",title:"EGT Configuration",showBackButton:!0,bindings:{egt:"telemetry.egt",egtOverrideActive:"overrides.egt.active",egtOverrideValue:"overrides.egt.value",egtFaultActive:"overrides.egt_fault.active"},...e}),this.pageTopBar=null}createSkeleton(){const e=super.createSkeleton(),t=this.el.querySelector("#page-top-bar-container");return t&&(this.pageTopBar=new fe({title:_.t("ui.egtOverrideTitle")}),this.pageTopBar.mount(t)),e}onBindEvents(){o.debug("EgtSettingsPage","onBindEvents");const e=this.el.querySelector("#egt-override-toggle"),t=this.el.querySelector("#egt-slider"),i=this.el.querySelectorAll(".preset-badge"),a=this.el.querySelector("#egt-fault-toggle");e&&e.addEventListener("change",n=>{const c=n.target.checked;M.toggleOverride("egt",c),this._updateUIState(c),c&&a&&a.checked&&(a.checked=!1,M.injectFault("egt_overheat",!1))}),t&&t.addEventListener("input",n=>{const c=parseFloat(n.target.value);this._updateSliderLabel(c),M.setValue("egt",c)}),i.forEach(n=>{n.addEventListener("click",()=>{const c=parseFloat(n.getAttribute("data-value"));e&&!e.checked&&(e.checked=!0,M.toggleOverride("egt",!0),this._updateUIState(!0),a&&a.checked&&(a.checked=!1,M.injectFault("egt_overheat",!1))),t&&(t.value=c),this._updateSliderLabel(c),M.setValue("egt",c)})}),a&&a.addEventListener("change",n=>{const c=n.target.checked;M.injectFault("egt_overheat",c),c&&e&&e.checked&&(e.checked=!1,M.toggleOverride("egt",!1),this._updateUIState(!1))})}onActivate(){super.onActivate(),o.debug("EgtSettingsPage","Activated"),this._syncState()}onDataChange(e,t){if(this.el){if(e==="egtOverrideActive"){const i=this.el.querySelector("#egt-override-toggle");i&&(i.checked=!!t),this._updateUIState(!!t)}else if(e==="egtOverrideValue"){const i=this.el.querySelector("#egt-slider");i&&!this._isUserInteractingWithSlider()&&(i.value=t,this._updateSliderLabel(t))}else if(e==="egtFaultActive"){const i=this.el.querySelector("#egt-fault-toggle");i&&(i.checked=!!t);const a=this.el.querySelector("#egt-fault-card");a&&(t?a.classList.add("fault-active"):a.classList.remove("fault-active"))}else if(e==="egt"){const i=this.el.querySelector("#egt-live-value");i&&(i.textContent=Number(t).toFixed(1))}}}renderContent(){return`
      <div id="page-top-bar-container"></div>

      <div class="settings-content">
        <div class="info-card">
          <p class="description">${_.t("ui.egtOverrideDesc")}</p>
        </div>

        <!-- OVERRIDE TOGGLE CARD -->
        <div class="settings-card">
          <div class="toggle-container">
            <div class="toggle-details">
              <span class="toggle-title">${_.t("ui.overrideToggle")}</span>
              <span class="toggle-description">Bypasses thermodynamic model updates</span>
            </div>
            <label class="switch">
              <input type="checkbox" id="egt-override-toggle">
              <span class="switch-slider"></span>
            </label>
          </div>
        </div>

        <!-- SLIDER CONTROL CARD -->
        <div class="settings-card slider-card disabled" id="egt-slider-card">
          <div class="slider-header">
            <span class="slider-title">${_.t("ui.targetEgt")}</span>
            <span class="slider-value" id="egt-slider-value">20.0</span>
            <span class="slider-unit">°C</span>
          </div>
          <div class="slider-container">
            <input type="range" id="egt-slider" min="20" max="1000" step="10" value="20">
            <div class="slider-ticks">
              <span>20°C</span>
              <span>250°C</span>
              <span>500°C</span>
              <span>750°C</span>
              <span>1000°C</span>
            </div>
          </div>
        </div>

        <!-- QUICK PRESETS CARD -->
        <div class="settings-card">
          <div class="card-header-simple">
            <span class="card-title">${_.t("ui.presets")}</span>
          </div>
          <div class="presets-grid">
            <button class="preset-badge" data-value="20">
              <span class="preset-name">Ambient</span>
              <span class="preset-val">20°C</span>
            </button>
            <button class="preset-badge" data-value="200">
              <span class="preset-name">Warm</span>
              <span class="preset-val">200°C</span>
            </button>
            <button class="preset-badge" data-value="500">
              <span class="preset-name">Normal</span>
              <span class="preset-val">500°C</span>
            </button>
            <button class="preset-badge" data-value="750">
              <span class="preset-name">Hot</span>
              <span class="preset-val">750°C</span>
            </button>
            <button class="preset-badge" data-value="900">
              <span class="preset-name">Max</span>
              <span class="preset-val">900°C</span>
            </button>
          </div>
        </div>

        <!-- FAULT INJECTION CARD -->
        <div class="settings-card" id="egt-fault-card">
          <div class="toggle-container">
            <div class="toggle-details">
              <span class="toggle-title">${_.t("ui.injectFaultToggle")}</span>
              <span class="toggle-description">Rapidly ramps EGT above the ALARM threshold (850°C) to test fail-safes</span>
            </div>
            <label class="switch warning-switch">
              <input type="checkbox" id="egt-fault-toggle">
              <span class="switch-slider"></span>
            </label>
          </div>
        </div>

        <!-- LIVE TELEMETRY CARD -->
        <div class="settings-card">
          <div class="live-status-container">
            <span class="live-status-title">Live Exhaust Gas Temp</span>
            <div class="live-status-details">
              <span class="live-status-value" id="egt-live-value">20.0</span>
              <span class="live-status-unit">°C</span>
            </div>
          </div>
        </div>

      </div>
    `}_syncState(){var m,E,S;const e=(m=this.data.egtOverrideActive)!=null?m:!1,t=(E=this.data.egtOverrideValue)!=null?E:20,i=(S=this.data.egtFaultActive)!=null?S:!1,a=this.el.querySelector("#egt-override-toggle"),n=this.el.querySelector("#egt-slider"),c=this.el.querySelector("#egt-fault-toggle"),g=this.el.querySelector("#egt-live-value");a&&(a.checked=e),n&&(n.value=t,this._updateSliderLabel(t)),c&&(c.checked=i),g&&(g.textContent=Number(this.data.egt||20).toFixed(1)),this._updateUIState(e);const b=this.el.querySelector("#egt-fault-card");b&&(i?b.classList.add("fault-active"):b.classList.remove("fault-active"))}_updateUIState(e){const t=this.el.querySelector("#egt-slider-card"),i=this.el.querySelector("#egt-slider");t&&(e?t.classList.remove("disabled"):t.classList.add("disabled")),i&&(i.disabled=!e)}_updateSliderLabel(e){const t=this.el.querySelector("#egt-slider-value");t&&(t.textContent=Number(e).toFixed(1))}_isUserInteractingWithSlider(){const e=this.el.querySelector("#egt-slider");return e&&document.activeElement===e}onDestroy(){super.onDestroy(),this.pageTopBar&&(this.pageTopBar.destroy(),this.pageTopBar=null)}}class Ut{constructor(e={}){this.config={socketUrl:e.socketUrl||"192.168.4.1/ws",appVersion:e.appVersion||"dev",enableDebugLogs:e.enableDebugLogs!==void 0?e.enableDebugLogs:!1,autoConnectSocket:e.autoConnectSocket!==void 0?e.autoConnectSocket:!1,useMockData:e.useMockData!==void 0?e.useMockData:!1},o.setDebugMode(this.config.enableDebugLogs),this.UI={},this.pages=[],this.managers={},this.loadingSpinner=null,this.unsubSocketStatus=null,this.unsubSocketMessage=null,this._mockEmulatorStop=null,this._beforeUnloadCleanupBound=!1}async bootstrap(){var e;try{o.info("════════════════════════════════════════"),o.info("  ECU Simulator WebUI - Bootstrap Start "),o.info(`  Version: ${this.config.appVersion}        `),o.info("════════════════════════════════════════"),await this.initSocket(),this.config.useMockData&&(o.warn("🧪 Mock mode enabled - running local engine simulation"),Rt(y,I),this._mockEmulatorStop=wt(y,I)),this.renderSkeleton(),this.initManagers(),this.registerPages(),this.initUI(),this._setupCleanup(),this.managers.navigator.navigateTo("dashboardPage"),o.info("✅ ECU Simulator bootstrap completed!"),o.info("════════════════════════════════════════"),(this.config.enableDebugLogs||this.config.useMockData)&&(window.EcuSim={App:this,Store:y,Socket:B,i18n:_,NavigatorManager:this.managers.navigator,SidebarManager:this.managers.sidebar,CommandManager:this.managers.command})}catch(t){o.error("❌ Bootstrap failed:",t),y.set(((e=I.APP)==null?void 0:e.ERROR)||"socket.state","Bootstrap failed")}}async initSocket(){o.info("🔌 Initializing Socket..."),B.setConfig({url:this.config.socketUrl}),this.unsubSocketStatus&&this.unsubSocketStatus(),this.unsubSocketStatus=B.onStatus(e=>{o.debug(`📡 Socket status: ${e}`),y.set(I.SOCKET.STATE,e)}),this.unsubSocketMessage&&this.unsubSocketMessage(),this.unsubSocketMessage=B.onMessage(e=>{Ke(e)}),this.config.autoConnectSocket?(o.info("🔌 Connecting to WebSocket..."),B.connect()):this.config.useMockData&&y.set(I.SOCKET.STATE,L.CONNECTED),o.info("✅ Socket initialized")}renderSkeleton(){o.info("🏗️ Rendering page skeletons...");const e=document.querySelector(".pages-container");if(!e){o.error("❌ Pages container not found in DOM");return}this.pages=[new Bt,new $t,new xt,new qt],this.pages.forEach(t=>{const i=t.createSkeleton();e.appendChild(i),o.debug(`  ✓ ${t.pageId} skeleton created`)}),o.info(`✅ ${this.pages.length} page skeletons rendered`)}initManagers(){o.info("🎛️ Initializing Managers..."),V.init(),this.managers.navigator=V,me.init(),this.managers.modal=me,re.init(),this.managers.sidebar=re,M.init(),this.managers.command=M,re.setupNavigation(V),o.info("✅ Managers initialized")}registerPages(){o.info("📄 Registering pages..."),this.pages.forEach(e=>{V.registerPage(e.pageId,e),e.bindEvents(),o.debug(`  ✓ ${e.pageId} registered`)}),o.info(`✅ ${this.pages.length} pages registered`)}initUI(){o.info("🧩 Initializing UI components...");const e=new Mt({onThemeToggle:i=>{o.debug(`🎨 Theme changed: ${i}`)},onMenuClick:()=>{this.managers.sidebar.open()}}),t=document.querySelector(".top-bar");t?(t.innerHTML="",e.mount(t),e.bindEvents(),e.activate(),this.UI.topbar=e,o.debug("  ✓ TopBar created")):o.error("❌ TopBar container not found"),o.info("✅ UI components initialized")}_setupCleanup(){this._beforeUnloadCleanupBound||(window.addEventListener("beforeunload",()=>{if(this.unsubSocketStatus&&this.unsubSocketStatus(),this.unsubSocketMessage&&this.unsubSocketMessage(),this._mockEmulatorStop)try{this._mockEmulatorStop()}catch(e){}}),this._beforeUnloadCleanupBound=!0)}}function Vt(){var c,g,b,m;const s=window.APP_CONFIG||{},e=new URL(window.location.href),t=e.searchParams.has("mock")||e.searchParams.has("demo")||e.searchParams.has("emulator"),i=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"||window.location.hostname==="",a=t||i||!!((c=s.useMockData)!=null?c:s.useMock),n=!a&&!!((g=s.autoConnectSocket)==null||g);return{socketUrl:s.socketUrl||window.location.host+"/ws",appVersion:window.APP_VERSION||"dev",enableDebugLogs:!!((m=(b=s.enableLogs)!=null?b:s.enableDebugLogs)!=null&&m),useMockData:a,autoConnectSocket:n}}async function Ee(){const s=Vt();await new Ut(s).bootstrap()}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Ee,{once:!0}):Ee();
